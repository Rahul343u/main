myApp.run(['$anchorScroll', function($anchorScroll) {
  $anchorScroll.yOffset = 50;   // always scroll by 50 extra pixels
}]);
myApp.controller("chatController", function($scope,$http,$timeout,$anchorScroll,$location,$localStorage){

                     var message =[
                   ];
                   $scope.userRoleFlag = '';
                    $scope.trainingRequestQuery = '';
                    $scope.trainingRequests = '';
                    $scope.fulfillRequestflag = false;
                    $scope.fulfillRequestID = '';
                    $scope.notrainingRequests = false;
                    $http.get("/trainerRole").then(function(response) {
                            $scope.userRoleFlag = response.data.role;
                          });


                    $scope.sayHi = function(){
                      $scope.query = 'Hi Chappie';
                      myquery();
                    }


                    $scope.myquery =myquery;
                     $scope.message= message;
                     function myquery(){
                         var linkflag = false;
                       var message1 ={chat:$scope.query,
                                    classname:'right-chat',
                                    image :'/images/man02.png'};
                     message.push(message1);
                      setTimeout(function() {
                        var scroll = document.getElementById('chat-section');
                        scroll.scrollTop = scroll.scrollHeight;
                        scroll.animate({scrollTop: scroll.scrollHeight});
                    }, 1);

                    var config = {
                            headers : {
                                'Content-Type': 'application/json'
                            }
                        }
                        var data = {query:$scope.query.toLowerCase()};

                    $http.post("/chappie" , data , config).then(function (data, status, headers, config) {
                      var message1 ={chat:data.data.data[0].answer,
                                   classname:'left-chat',
                                   image :'/images/chappie.jpg',
                                    link : data.data.data[0].link,
                                    linktag:data.data.data[0].linktag,
                                    trainingRequest : data.data.data[0].trainingRequest
                                  };
                    message.push(message1);
                      $scope.trainingRequestQuery = data.data.data[0].trainingRequestQuery;
                    setTimeout(function() {
                      var scroll = document.getElementById('chat-section');
                      scroll.scrollTop = scroll.scrollHeight;
                      scroll.animate({scrollTop: scroll.scrollHeight});
                  }, 1);
                });

                    $scope.query = '';
                   }

                   $scope.trainChappie = function(){
                     var linktrain = '';
                     var tagtrain1 = '';

                     if($scope.tag1tolearn){tagtrain1 = $scope.tag1tolearn.toLowerCase()};
                     if($scope.linktolearn){linktrain = $scope.linktolearn.toLowerCase()};

                       if($scope.querytolearn && $scope.answertolearn)
                       {
                         var data =  {
                             query: $scope.querytolearn.toLowerCase(),
                             answer: $scope.answertolearn,
                             tag1: tagtrain1,
                             link: linktrain,
                             linktag:$scope.linktagtolearn,
                             status: "pending"
                           };
                           var config = {
                                   headers : {
                                       'Content-Type': 'application/json'
                                   }
                               }

                               $http.post("/trainChappie" , data , config).then(function (data, status, headers, config) {
                                 var message1 ={chat:data.data.data[0].answer,
                                              classname:'left-chat',
                                              image :'/images/chappie.jpg'};
                               message.push(message1);
                               setTimeout(function() {
                                 var scroll = document.getElementById('chat-section');
                                 scroll.scrollTop = scroll.scrollHeight;
                                 scroll.animate({scrollTop: scroll.scrollHeight});
                             }, 1);
                             });


      // Alternate queries
      if($scope.query1tolearn){
      var data =  {
          query: $scope.query1tolearn.toLowerCase(),
          answer: $scope.answertolearn,
          tag1: tagtrain1,
          link: linktrain,
          linktag:$scope.linktagtolearn,
          status: "pending"
        };
        var config = {
                headers : {
                    'Content-Type': 'application/json'
                }
            }
             $http.post("/trainChappie" , data , config).then(function (data, status, headers, config) {});
          };

          if($scope.query2tolearn){
          var data =  {
              query: $scope.query2tolearn.toLowerCase(),
              answer: $scope.answertolearn,
              tag1: tagtrain1,
              link: linktrain,
              linktag:$scope.linktagtolearn,
              status: "pending"
            };
            var config = {
                    headers : {
                        'Content-Type': 'application/json'
                    }
                }
                 $http.post("/trainChappie" , data , config).then(function (data, status, headers, config) {});
              };

              if($scope.query3tolearn){
              var data =  {
                  query: $scope.query3tolearn.toLowerCase(),
                  answer: $scope.answertolearn,
                  tag1: tagtrain1,
                  link: linktrain,
                  linktag:$scope.linktagtolearn,
                  status: "pending"
                };
                var config = {
                        headers : {
                            'Content-Type': 'application/json'
                        }
                    }
                     $http.post("/trainChappie" , data , config).then(function (data, status, headers, config) {});
                  };

                  if($scope.query4tolearn){
                  var data =  {
                      query: $scope.query4tolearn.toLowerCase(),
                      answer: $scope.answertolearn,
                      tag1: tagtrain1,
                      link: linktrain,
                      linktag:$scope.linktagtolearn,
                      status: "pending"
                    };
                    var config = {
                            headers : {
                                'Content-Type': 'application/json'
                            }
                        }
                         $http.post("/trainChappie" , data , config).then(function (data, status, headers, config) {});
                      };

                      if($scope.query5tolearn){
                      var data =  {
                          query: $scope.query5tolearn.toLowerCase(),
                          answer: $scope.answertolearn,
                          tag1: tagtrain1,
                          link: linktrain,
                          linktag:$scope.linktagtolearn,
                          status: "pending"
                        };
                        var config = {
                                headers : {
                                    'Content-Type': 'application/json'
                                }
                            }
                             $http.post("/trainChappie" , data , config).then(function (data, status, headers, config) {});
                          };

                          if($scope.query6tolearn){
                          var data =  {
                              query: $scope.query6tolearn.toLowerCase(),
                              answer: $scope.answertolearn,
                              tag1: tagtrain1,
                              link: linktrain,
                              linktag:$scope.linktagtolearn,
                              status: "pending"
                            };
                            var config = {
                                    headers : {
                                        'Content-Type': 'application/json'
                                    }
                                }
                                 $http.post("/trainChappie" , data , config).then(function (data, status, headers, config) {});
                              };

                              if($scope.query7tolearn){
                              var data =  {
                                  query: $scope.query7tolearn.toLowerCase(),
                                  answer: $scope.answertolearn,
                                  tag1: tagtrain1,
                                  link: linktrain,
                                  linktag:$scope.linktagtolearn,
                                  status: "pending"
                                };
                                var config = {
                                        headers : {
                                            'Content-Type': 'application/json'
                                        }
                                    }
                                     $http.post("/trainChappie" , data , config).then(function (data, status, headers, config) {});
                                  };


                                  if($scope.query8tolearn){
                                  var data =  {
                                      query: $scope.query8tolearn.toLowerCase(),
                                      answer: $scope.answertolearn,
                                      tag1: tagtrain1,
                                      link: linktrain,
                                      linktag:$scope.linktagtolearn,
                                      status: "pending"
                                    };
                                    var config = {
                                            headers : {
                                                'Content-Type': 'application/json'
                                            }
                                        }
                                         $http.post("/trainChappie" , data , config).then(function (data, status, headers, config) {});
                                      };


    // Training Request Fulfill Section
          if($scope.fulfillRequestflag){
            $scope.fulfillRequestflag = false;
            gotoAnchor('fulfillRequest');
            var data =  {
                _id:$scope.fulfillRequestID
              };
              var config = {
                      headers : {
                          'Content-Type': 'application/json'
                      }
                  }
                   $http.post("/removeFulfilledRequest" , data , config).then(function (data, status, headers, config) {
                     var message1 ={chat:data.data.data[0].answer,
                                  classname:'left-chat',
                                  image :'/images/chappie.jpg'};
                   message.push(message1);
                   setTimeout(function() {
                     var scroll = document.getElementById('chat-section');
                     scroll.scrollTop = scroll.scrollHeight;
                     scroll.animate({scrollTop: scroll.scrollHeight});
                 }, 1);

                   });
                   $http.get("/getTrainingRequests").then(function(response) {
                           $scope.trainingRequests = response.data.trainingRequests;

                         });
            }



                       }else{
                         var message1 ={chat:'you need to provide Query and Answer both, So that I can learn properly. You can also provide some alternate queries for same answer. Thanks you.',
                                      classname:'left-chat',
                                      image :'/images/chappie.jpg'};
                       message.push(message1);
                       setTimeout(function() {
                         var scroll = document.getElementById('chat-section');
                         scroll.scrollTop = scroll.scrollHeight;
                         scroll.animate({scrollTop: scroll.scrollHeight});
                     }, 1);
                   };

                   $scope.querytolearn='';
                   $scope.answertolearn='';
                   $scope.linktolearn='';
                   $scope.tag1tolearn='';
                   $scope.query1tolearn='';
                    $scope.query2tolearn='';
                     $scope.query3tolearn='';
                      $scope.query4tolearn='';
                       $scope.query5tolearn='';
                        $scope.query6tolearn='';
                         $scope.query7tolearn='';
                          $scope.query8tolearn='';
                $scope.linktagtolearn = '';

                 };

                   $scope.trainingRequestmodal = function(){
                    var trainingRequestmodal = document.getElementById('trainingRequestModal');
                    trainingRequestmodal.style.display = "block";
                 };

                 $scope.trainingRequestCancel = function(){
                  var trainingRequestmodal = document.getElementById('trainingRequestModal');
                  trainingRequestmodal.style.display = "none";
               };

               $scope.trainingModal = function(){
                 $http.get("/trainerRole").then(function(response) {
                         $scope.userRoleFlag = response.data.role;

                         if(response.data.role !== 'user'){
                           var trainingModal = document.getElementById('trainingModal');
                           trainingModal.style.display = "block";
                         }
                       });

             };
                $scope.trainingRequestSubmit = function(){
                  var data =  {
                      query: $scope.trainingRequestQuery.toLowerCase(),
                      answer: $scope.trainingRequestAnswer,
                      link: $scope.trainingRequestLink,
                      linktag:$scope.trainingRequestLinktag,
                      status:"new"
                    };
                    var config = {
                            headers : {
                                'Content-Type': 'application/json'
                            }
                        }
                         $http.post("/trainingrequest" , data , config).then(function (data, status, headers, config) {
                           var message1 ={chat:data.data.data[0].answer,
                                        classname:'left-chat',
                                        image :'/images/chappie.jpg'};
                         message.push(message1);
                         setTimeout(function() {
                           var scroll = document.getElementById('chat-section');
                           scroll.scrollTop = scroll.scrollHeight;
                           scroll.animate({scrollTop: scroll.scrollHeight});
                       }, 1);

                         });
                         var trainingRequestmodal = document.getElementById('trainingRequestModal');
                         trainingRequestmodal.style.display = "none";
                         $scope.trainingRequestQuery = "";
                         $scope.trainingRequestAnswer = "";
                         $scope.trainingRequestLink = "";
                         $scope.trainingRequestLinktag = "";
                      };

                      $scope.getTrainingRequests =function(){
                        $http.get("/getTrainingRequests").then(function(response) {
                                $scope.trainingRequests = response.data.trainingRequests;
                                $scope.notrainingRequests = true;
                              });
                      };
                      $scope.fulfillRequest = function(request){
                        $scope.querytolearn=request.query;
                        $scope.answertolearn=request.answer;
                        $scope.linktolearn=request.link;
                     $scope.linktagtolearn = request.linktag;

                     $scope.fulfillRequestflag = true;
                     $scope.fulfillRequestID = request._id;
                      gotoAnchor('trainMe');
                      };

                    function gotoAnchor(x) {
                             var newHash = x;
                             if ($location.hash() !== newHash) {
                               $location.hash(x);
                             } else {
                               $anchorScroll();
                             }
                           };

                           $scope.gotoAnchor = gotoAnchor;

                          $scope.notRelaventRequest = function(request){
                          var data =  {
                              _id:request._id
                            };
                            var config = {
                                    headers : {
                                        'Content-Type': 'application/json'
                                    }
                                }
                                 $http.post("/notRelaventRequest" , data , config).then(function (data, status, headers, config) {
                                   var message1 ={chat:data.data.data[0].answer,
                                                classname:'left-chat',
                                                image :'/images/chappie.jpg'};
                                 message.push(message1);
                                 setTimeout(function() {
                                   var scroll = document.getElementById('chat-section');
                                   scroll.scrollTop = scroll.scrollHeight;
                                   scroll.animate({scrollTop: scroll.scrollHeight});
                               }, 1);

                                 });
                                 $http.get("/getTrainingRequests").then(function(response) {
                                         $scope.trainingRequests = response.data.trainingRequests;

                                       });
                           };

                           $scope.alreadyDonRequest = function(request){
                           var data =  {
                               _id:request._id
                             };
                             var config = {
                                     headers : {
                                         'Content-Type': 'application/json'
                                     }
                                 }
                                  $http.post("/alreadyDonRequest" , data , config).then(function (data, status, headers, config) {
                                    var message1 ={chat:data.data.data[0].answer,
                                                 classname:'left-chat',
                                                 image :'/images/chappie.jpg'};
                                  message.push(message1);
                                  setTimeout(function() {
                                    var scroll = document.getElementById('chat-section');
                                    scroll.scrollTop = scroll.scrollHeight;
                                    scroll.animate({scrollTop: scroll.scrollHeight});
                                }, 1);

                                  });
                                  $http.get("/getTrainingRequests").then(function(response) {
                                          $scope.trainingRequests = response.data.trainingRequests;

                                        });
                            };



                   });







                   // Get the modal
                   var modal = document.getElementById('trainingModal');


                   // Get the button that opens the modal
                   var chatbottraininglink = document.getElementById("chatbottraininglink");


                   // Get the <span> element that closes the modal
                   var span = document.getElementById("closeTaraining");

                   // Get the cancel button element that closes the modal
                   var trainCancel = document.getElementById("trainingCancel");
                   trainCancel.onclick = function() {
                       modal.style.display = "none";
                   };

                   // When the user clicks the button, open the modal
                   chatbottraininglink.onclick = function() {
                       modal.style.display = "block";
                   };

                   // When the user clicks on <span> (x), close the modal
                   span.onclick = function() {
                       modal.style.display = "none";
                   };
                 // When the user clicks on cancel, close the modal


                   // When the user clicks anywhere outside of the modal, close it
                   window.onclick = function(event) {
                       if (event.target == modal) {
                           modal.style.display = "none";
                       }

                 };
