$(document).ready(function(){
    $(".left-first-section").click(function(){
          $('.main-section').toggleClass("open-more");
      });

      $(".fa-minus").click(function(){
            $('.main-section').toggleClass("open-more");
        });



        $(".fa-clone").click(function(){
              $('.main-section').toggleClass("open-more");
          });


        $(".fa-times").click(function(){
            var x = document.getElementById("taffy-bot");
            x.style.display = "none";
          });

  });
