var myApp = angular.module("myModule",[])
myApp.factory('Excel',function($window){
        var uri='data:application/vnd.ms-excel;base64,',
            template='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
            base64=function(s){return $window.btoa(unescape(encodeURIComponent(s)));},
            format=function(s,c){return s.replace(/{(\w+)}/g,function(m,p){return c[p];})};
        return {
            tableToExcel:function(tableId,worksheetName){
                var table=$(tableId),
                    ctx={worksheet:worksheetName,table:table.html()},
                    href=uri+base64(format(template,ctx));
                return href;
            }
        };
    })
			.controller("myController", function(Excel,$timeout,$scope,$http){
                    $scope.exportToExcel=function(){
                                          $scope.sn=false;
                                          setTimeout(function() {
                                            var exportHref=Excel.tableToExcel(myTable,'WireWorkbenchDataExport');
                                            $timeout(function(){location.href=exportHref;},100); // trigger download
                                          }, 0);
                                          setTimeout(function() {
                                          $scope.sn=true;
                                          $scope.user1 = "User 1";
                                          $scope.user2 = "User 2";
                                        }, 1);

                                        };


      $http.get("/item/planning1").then(function(response) {
              $scope.proje1 = response.data;
            });


        $scope.tagName =function(){
                    var config = {
                            headers : {
                                'Content-Type': 'application/json'
                            }
                        }
                    var data = $scope.projectName;
                    $http.post("/item/getTestcastags" , data , config).then(function (data, status, headers, config) {
                      $scope.testtagname = data.data.tags;
                    })
                  };

        $scope.loadtestcases =function(){
              					 $('.ajax-loader').css("visibility","visible");
              					 var elem = document.getElementById("showTestSteps");
              					 elem.value = "/pubpartials/tablewithoutsteps.ejs";
                         $scope.tableview = "/pubpartials/tablewithoutsteps.ejs";
              					 $("tbody#myTablerows tr").remove();
              						$("#showTestSteps").html('Show Steps');
                        var config = {
                                headers : {
                                    'Content-Type': 'application/json'
                                }
                            }
                        var data ={
                          projName :$scope.projectName.name,
                          tagName  :$scope.tagTest.value
                        } ;
                        $http.post("/item/testcases1" , data , config).then(function (data, status, headers, config) {
                         $scope.testcaselist = data.data.testcases;
                         $scope.actionName = 'Launch OPUS';
                         $scope.actionDes = 'This action will launch OPUS.';
              					  $('.ajax-loader').css("visibility","hidden");
                        });

                        $http.post("/item/testcases" , data , config).then(function (data, status, headers, config) {
                          $scope.actionName = '';
                          $scope.actionDes = '';
                         $scope.testcaselist = data.data.testcases;
                        })

                      };
			$scope.showTestSteps = function(){
                				var elem = document.getElementById("showTestSteps");
                		    if (elem.value=="/pubpartials/tablewithoutsteps.ejs") {
                		      elem.value = "/pubpartials/tablewithsteps.ejs";
                		      $("#showTestSteps").html('Hide Steps');
                					$scope.tableview = "/pubpartials/tablewithsteps.ejs";
                		    }
                		      else {
                		        elem.value = "/pubpartials/tablewithoutsteps.ejs";
                		          $("#showTestSteps").html('Show Steps');
                							$scope.tableview = "/pubpartials/tablewithoutsteps.ejs";
                		      }
                };

$scope.tableview = "/pubpartials/tablewithoutsteps.ejs";
$scope.sortcol = "name";
$scope.reverseSort = false;
$scope.sortData= function(column){
				   $scope.reverseSort = ($scope.sortcol==column)? !$scope.reverseSort:false;
				   $scope.sortcol= column;
			   }

			   $scope.getSortClass= function(column){
				  if($scope.sortcol== column){
					return $scope.reverseSort ? 'arrowDown':'arrowUp';
				  }
				  return '';
			   }

//Flag to controll the visibility of rows and columns
$scope.sn=true;


//popupmodel TestPhase
var testPhase = ['Unassigned', 'Assembly Test' , 'CLEC Test' , 'End to End Test (E2E)', 'Integrated Systems Test (IST)','Integrated Systems Testing',
'Iteration Test', 'Performance/Load','Production','Production Validation Test (PVT)','Rapid Deployment Test (RD)','Sanity / Shakeout', 'Security',
'Undefined','Unit Test','User Acceptance Test (UAT)'];

var regressionProgression = ['Progression','Regression'];

var nonMotsTeam = ['RCC ST-OPUS','RCC ST-OPUSMBL'];

var application = ['OPUS - C:18257'];

$scope.testPhase = testPhase;
$scope.regressionProgression = regressionProgression;
$scope.nonMotsTeam = nonMotsTeam;
$scope.application = application;
$scope.testPhasevalue = 'Integrated Systems Test (IST)';
$scope.regprogvalue = 'Regression' ;
$scope.nonMotsTeamvalue = 'RCC ST-OPUS';
$scope.applicationvalue = 'OPUS - C:18257';

var projectName =[];

  // Get the modal
  var modal = document.getElementById('myModal');

  // Get the button that opens the modal
  var btn = document.getElementById("myBtn");

  // Get the <span> element that closes the modal
  var span = document.getElementsByClassName("close")[0];

  // When the user clicks the button, open the modal
  btn.onclick = function() {
      modal.style.display = "block";
  };

  // When the user clicks on <span> (x), close the modal
  span.onclick = function() {
      modal.style.display = "none";
  };
// When the user clicks on cancel, close the modal

ExportCancel.onclick = function() {
    modal.style.display = "none";
};
ExportSubmit.onclick = function() {
    modal.style.display = "none";
};

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
      if (event.target == modal) {
          modal.style.display = "none";
      }

};

// scroll controller
$(window).scroll(function () {
  var scroll = $(window).height() + $(window).scrollTop() >= $(window).height() + 50;
  var top = $(window).height() + $(window).scrollTop() <= $(window).height() + 50;
if(scroll)
{
$('#allControll').hide();
}

if(top)
{
$('#allControll').show();
}

});

$scope.user1 = "User 1";
$scope.user2 = "User 2";

});
