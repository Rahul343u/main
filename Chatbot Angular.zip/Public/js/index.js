var async = require('async');
var MongoClient = require('mongodb').MongoClient;

//console.log("In Index.js we are printing application : "+ req.body.application);

var AUTOMATION_URL = 'mongodb://10.13.66.63:27017/automationframework';
var EXECUTION_URL = 'mongodb://10.13.66.63:27017/taffy';
var TAFFYBOT_URL = 'mongodb://10.13.66.63:27017/taffybots';
//var TAFFYBOT_URL = 'mongodb://10.13.66.59:27017/chatbottest';

var database = {
automation: async.apply(MongoClient.connect, AUTOMATION_URL),
//execution:async.apply(MongoClient.connect,EXECUTION_URL)
taffybot:async.apply(MongoClient.connect, TAFFYBOT_URL)
};

console.log('Connected to DB');
module.exports = function (cb) {
async.parallel(database, cb)
};
