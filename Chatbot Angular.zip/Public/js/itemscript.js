$(document).ready(function(){
var testdata = [];

  $('#project_id').change(function() {
  		$.ajax({
      url: "/getTestcastags",
  		type: "POST",
  		data: {project_id:$(this).val()},
  		dataType:"json",
  		success: function(data)
  		{
  			$("#Testcasetag").empty();
  			for(var i=0;i<data.testtagname.length;i++){
  			$("#Testcasetag").append($("<option></option>").val(data.testtagname[i].value).html(data.testtagname[i].value));
  			}

  		}

      });
  });


  $('#btn-submit2').click(function() {
  		$.ajax({
        beforeSend : function()
        	   {
        	    $('.ajax-loader').css("visibility","visible");
              var elem = document.getElementById("showTestSteps");
              elem.value = "Show Steps";
                $("#showTestSteps").html('Show Steps');
        	   },
  		 url: "/testcases",
  		type: "POST",
  		data: {project_id:$('select[id=project_id]').val() , tag :$('select[id=Testcasetag]').val() },
  		dataType:"json",
  		success: function(data)
  		{
        testdata=data;
    createTable(testdata,0);
    },complete : function() {
  $('.ajax-loader').css("visibility","hidden");
                        }
      });

  });


  $('#showTestSteps').click(function() {
    var elem = document.getElementById("showTestSteps");
    if (elem.value=="Show Steps") {
      elem.value = "Hide Steps";
      $("#showTestSteps").html('Hide Steps');
      createTable(testdata,1);
    }
      else {
        elem.value = "Show Steps";
          $("#showTestSteps").html('Show Steps');
        createTable(testdata,0);
      }
});




function createTable(data,cons)
{
        delRow();
              for (var i=0; i<data.testcases.length; i++){
                  for(var j=0; j < data.testcases[i].actiondetails.length; j++){
                    if(j==0){
                            var tableRef = document.getElementById('myTable').getElementsByTagName('tbody')[0];
                            var row   = tableRef.insertRow(tableRef.rows.length);
                             var cell1 = row.insertCell(0);
                             var cell2 = row.insertCell(1);
                             var cell3 = row.insertCell(2);
                             var cell4 = row.insertCell(3);
                             var cell5 = row.insertCell(4);
                             var cell6 = row.insertCell(5);
                             var cell7 = row.insertCell(6);
                             var cell8 = row.insertCell(7);
                             var cell9 = row.insertCell(8);
                             var cell10 = row.insertCell(9);
                             var cell11 = row.insertCell(10);
                             var cell12 = row.insertCell(11);
                             var cell13 = row.insertCell(12);
                             var cell14 = row.insertCell(13);
                             var cell15 = row.insertCell(14);
                             var cell16 = row.insertCell(15);
                             var cell17 = row.insertCell(16);
                             var cell18 = row.insertCell(17);
                             var cell19 = row.insertCell(18);
                             var cell20 = row.insertCell(19);
                             var cell21 = row.insertCell(20);
                             cell1.innerHTML = "<div contenteditable>" + data.testcases[i].name + "</div>";
                             cell2.innerHTML = "<div contenteditable>" + data.testcases[i].description + "</div>";
                             cell5.innerHTML ="<div contenteditable>" + data.testcases[i].actiondetails[j].name + "</div>";
                             cell6.innerHTML = "<div contenteditable>" + data.testcases[i].actiondetails[j].description + "</div>";
                             cell20.innerHTML = "<div contenteditable>" + data.testcases[i].name + "</div>";
                             cell21.innerHTML = "<div contenteditable>" + data.testcases[i].description + "</div>";
                          }
                            if(j!=0 && cons==1){
                                var tableRef = document.getElementById('myTable').getElementsByTagName('tbody')[0];
                                 var row   = tableRef.insertRow(tableRef.rows.length);
                                 var cell1 = row.insertCell(0);
                                 var cell2 = row.insertCell(1);
                                 var cell3 = row.insertCell(2);
                                 var cell4 = row.insertCell(3);
                                 var cell5 = row.insertCell(4);
                                 var cell6 = row.insertCell(5);
                                 var cell7 = row.insertCell(6);
                                 var cell8 = row.insertCell(7);
                                 var cell9 = row.insertCell(8);
                                 var cell10 = row.insertCell(9);
                                 var cell11 = row.insertCell(10);
                                 var cell12 = row.insertCell(11);
                                 var cell13 = row.insertCell(12);
                                 var cell14 = row.insertCell(13);
                                 var cell15 = row.insertCell(14);
                                 var cell16 = row.insertCell(15);
                                 var cell17 = row.insertCell(16);
                                 var cell18 = row.insertCell(17);
                                 var cell19 = row.insertCell(18);
                                 var cell20 = row.insertCell(19);
                                 var cell21 = row.insertCell(20);
                                 cell5.innerHTML ="<div contenteditable>" + data.testcases[i].actiondetails[j].name + "</div>";
                                 cell6.innerHTML = "<div contenteditable>" + data.testcases[i].actiondetails[j].description + "</div>";
                                }

  }
}
}


function delRow()
{
  var table = document. getElementById("myTable");
  for(var i = table. rows. length - 1; i > 1; i--)
                {
                table. deleteRow(i);
                }
}


$(function(){
    $('.export').click(function(){
        var url='data:application/vnd.ms-excel,' + encodeURIComponent($('#tableWrap').html())
        location.href=url
        return false
    })
})


});

function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
