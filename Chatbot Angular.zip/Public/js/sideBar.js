$(document).ready(function(){
    
    var myPieChart;
    var myBarGraph;
    var testcasenamee;
    $("#refresh").hide();
   $('#report').addClass('active');
    $('.project').get(0).selectedIndex=0;
    $.ajax({
            url :'/report',
            type : 'POST',
            dataType: 'json',
            success : function(rcvData){
                $("#refresh").show();
                //if(myBarGraph!=null){
                   testcasenamee = "sdfs";
                //}
               //  myBarGraph.reset();
                //console.log(myBarGraph);
                //$(".bar-Graph").show();
                var brandPrimary = '#33b35a';
                var dataContent=[];
                
                for(var j=0;j<rcvData.projectResult.length;j++){
                    getData = {
                        hidden:false,
                        label: rcvData.projectResult[j].projectName,
						data: [rcvData.projectResult[j].passCount,rcvData.projectResult[j].failCount,rcvData.projectResult[j].notRunCount],
						borderWidth: [1, 1, 1],
						backgroundColor: [
                            brandPrimary,
                            "#dc3545",
                            "#ffc107"
				        ]
                    }
                    dataContent.push(getData);  
                    //console.log(dataContent);
                }
                
                for(var i=0;i<rcvData.projectResult.length;i++){
                    var BARGRAPH = $('#barGraph');
                    //console.log(rcvData.projectResult[i].projectName);
                    myBarGraph = new Chart(BARGRAPH, {
				        type: 'bar',
                        data: {
                            labels: [
                                "Passed",
                                "Failed",
                                "No Run"
						      ],datasets: dataContent
                                          
                        }
					});
                }
               
            }
        });
     
    $("#refresh").click(function(){
       // $(".bar-Graph").hide();
         //myBarGraph.hide();
       
      //  $('#barGraph').destroy();
        $.ajax({
            url :'/report',
            type : 'POST',
            dataType: 'json',
            success : function(rcvData){
                
              if(myBarGraph!=null){
                  myBarGraph.destroy();
            }
               //  myBarGraph.reset();
                //console.log(myBarGraph);
                //$(".bar-Graph").show();
                var brandPrimary = '#33b35a';
                var dataContent=[];
                
                for(var j=0;j<rcvData.projectResult.length;j++){
                    getData = {
                        hidden:false,
                        label: rcvData.projectResult[j].projectName,
						data: [rcvData.projectResult[j].passCount,rcvData.projectResult[j].failCount,rcvData.projectResult[j].notRunCount],
						borderWidth: [1, 1, 1],
						backgroundColor: [
                            brandPrimary,
                            "#dc3545",
                            "#ffc107"
				        ]
                    }
                    dataContent.push(getData);  
                   // console.log(dataContent);
                }
                
                for(var i=0;i<rcvData.projectResult.length;i++){
                    var BARGRAPH = $('#barGraph');
                   // console.log(rcvData.projectResult[i].projectName);
                    myBarGraph = new Chart(BARGRAPH, {
				        type: 'bar',
                        data: {
                            labels: [
                                "Passed",
                                "Failed",
                                "No Run"
						      ],datasets: dataContent
                                          
                        }
					});
                }
               
            }
        });
    });
    
    
    
    $("#showDefault").click(function(){
        $("#sectionShow").hide();
        $("#sectionContent").hide();
        $("#searchContent").empty();
        $(".bar-Graph").show();
    })
    
   
   $(".application").click(function(){
       var application = $(this).attr("id");
       
       $.ajax({
           url : "/application",
           type:"POST",
           data : {application : application},
           dataType : "json"
       });
   });

    
    
    
    
    $(".dropdown").click(function(){
			$("#myDropdown").toggle();
		});
    
    
	$("#myInput").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#searchlist li").filter(function() {
			$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	});
    
    $(".project").change(function(){
        $("#myInput").val('');
        $('#searchContent').empty();
        var projectType = $(this).val();
        var projectId = $(this).attr("id");
         
        //console.log(projectType);
        $.ajax({
            url:"/"+projectId+"/project",
            type : "POST",
            data : {projectName : projectType},
            dataType : "json",
            success : function(projectData){
                
                //console.log("Project Data");
                //console.log(projectData);
                for(var i=0;i<projectData.projectList.length;i++){
                    console.log(projectData.projectList[i].name);
                    $('#searchContent').append("<div><li class='list-group-item list-group-item-action' id='"+projectData.projectList[i]._id+"'>"+projectData.projectList[i].name+"</li></div>");
                  
                }
                
            }
        });
    });
    
	
	$("#searchContent").on('click','li',function(){
        $("#testcasename").html("");
        $("#status").html("");
        $("#sectionShow").hide();
        $("#sectionContent").hide();
		var id = $(this).attr("id");
        
		var value = $(this).val();
        var newDiv=[];
        var newcontent=[];
		console.log("VALUE : " + value);
		$.ajax({
				url: "/"+id+'/report',
				type :"POST",
				data : {id:value,para:id},
				dataType:"json",
				success : function(resData){
                    $(".bar-Graph").hide();
					$("#sectionShow").show();
					$("#sectionContent").show();
					$("#contentName").html(resData.name);
					$("#contentPassed").html(resData.passed);
					$("#contentId").html(resData.id);
					$("#contentTestsetname").html('Test Set : '+resData.testsetname);
					$("#contentRuntime").html(resData.runtime);
					$("#contentFailed").html(resData.failed);
					$("#contentTotal").html(resData.total);
					$("#contentNotrun").html(resData.notRun);
					$("#contentUser").html(resData.user);
					$("#contentLastrundate").html('Last Run : '+resData.lastRunDate);

					var brandPrimary = '#33b35a';
					var PIECHART = $('#pieChart');
                   
					if(myPieChart!=null){
						myPieChart.destroy();
					}
                    console.log(myPieChart);
					myPieChart = new Chart(PIECHART, {
						type: 'doughnut',
						data: {
							labels: [
								"Passed",
								"Failed",
								"No Run"
							],
							
						datasets: [
						{
							data: [resData.passed,resData.failed,resData.notRun],
							borderWidth: [1, 1, 1],
							backgroundColor: [
							brandPrimary,
							"#dc3545",
							"#ffc107"
							]
							}]
						}
					});
				
				
				}
			});
        
			$.ajax({
                url: "/"+id+"/table",
				type :"POST",
				data : {para:id},
				dataType:"json",
                success : function(testCase){
                    $('#testCaseTable').empty();
                    for(i=0;i<=testCase.testCaseName.length;i++){
                      //  console.log(testCase);
                  
                       
                        if(testCase.testCaseName[i].result=="" ||testCase.testCaseName[i].result==undefined){
                            testCase.testCaseName[i].result="Not Run";
                            $('#testCaseTable').append("<tr><td>"+(i+1)+"</td><td id='"+testCase.testCaseName[i]._id+"'>"+testCase.testCaseName[i].name+"</td><td>"+testCase.testCaseName[i].status+"</td><td>"+testCase.testCaseName[i].result+"</td><td><div class='btn btn-danger disabled btn-sm' id='"+testCase.testCaseName[i]._id+"' style='cursor:no-drop'>No Screens!!</div></td></tr>");
                         
                           }
                        else{
                            $('#testCaseTable').append("<tr><td>"+(i+1)+"</td><td id='"+testCase.testCaseName[i]._id+"'><a>"+testCase.testCaseName[i].name+"</a></td><td>"+testCase.testCaseName[i].status+"</td><td>"+testCase.testCaseName[i].result+"</td><td><div class='viewScreen btn btn-success btn-sm' id='"+testCase.testCaseName[i]._id+"'>View Screens</div></td></tr>");
                           
                        }
                      //  console.log(testCase.testCaseName[i]._id + " " +i);
                       
                        
                    }
                }
            });
			
	});
    
     $('#testCaseTable').on('click','.viewScreen', function(){
         var screenId = $(this).attr('id');
        $('.downloadBtn').attr("style","display:block");
        $('.saveBtn').attr("style","display:none");
        $('.downloadBtn').removeClass('disabled');
        $.ajax({
             url : "/"+screenId+"/viewScreens",
             type : "POST",
             data : {screenId : screenId},
             dataType : "json",
             success : function(screenData){
                 
                console.log("screen name");
                console.log(screenData.screenId);
             //  $('.downloadBtn').attr('id',screenData.screenId);
                 $('.downloadBtn').attr('name',screenData.downloadName);
               //  $('.saveBtn').attr('name',screenData.downloadName);
                 $('#screenModal').modal('show');
                                    $("#screenBody").empty();
                
                for(var i=0;i<screenData.screenResult[0].children.length;i++){
                     for(var j=0;j<screenData.screenResult[0].children[i].children.length;j++){
                        var ss = screenData.screenResult[0].children[i].children[j].screenshot;
                         console.log(screenData.screenResult[0].children[i].children[j].screenshot);
                         if(screenData.screenResult[0].children[i].children[j].screenshot!=undefined){
                              $.ajax({
                                url : "/download/"+ss,
                                type : "post",
                                success : function(screens){
                                   
                                     for(var i=0;i<screens.binaryResult.length;i++){
                                         console.log(screens.binaryResult[i].file);
                                        //console.log(newData.binaryResult[i].file);
                                        var img = document.createElement('img');
                                         img.src = 'data:image/png;base64,' + screens.binaryResult[i].file;
                                         // console.log('Image Src');
                                         // console.log(img.src);
                    
                                         $('#screenBody').append("<img src="+img.src+" style=width:100%>");
                                                if(i==screens.binaryResult.length-1){
                                                    $(".loader").css("visibility","hidden");
                                                }
                    
                                     }
                                }
                            });   
                         }
                        
                         
                         
                        // console.log(screenData.screenResult[0].children[i].children[j].screenshot);
                         
                         /*if(screenData.screenResult[0].children[i].children[j].screenshot!=undefined){
                             $('#screenBody').append("<img src=http://10.13.66.82:3000/screenshots/"+screenData.screenResult[0].children[i].children[j].screenshot+" style=width:100%>");
                         }*/
                         
                     }
                 }
             }
         });
        
     });
	
    
 /*   $('.downloadBtn').click(function(){
        
        var downloadId = $('.downloadBtn').attr('id');
        $('.saveBtn').attr("style","display:block;cursor:pointer;");
        $(".loader").css("visibility","visible");
        $('.downloadBtn').attr("style","display:none");
         $.ajax({
            url : "/download",
            type : "POST",
            data : {screenId : downloadId},
            dataType : "json",
            //contentType: "image/png",
            success : function(newData){
                console.log('newData');
                $("#screenBody").empty();
               // console.log(newData);
                //console.log(newData.resultId[0].name);
               // console.log(newData.binaryResult.length);
               // console.log(newData.screensName);
                for(var i=0;i<newData.binaryResult.length;i++){
                    //console.log(newData.binaryResult[i].file);
                    var img = document.createElement('img');
                    img.src = 'data:image/png;base64,' + newData.binaryResult[i].file;
                   // console.log('Image Src');
                   // console.log(img.src);
                    
                    $('#screenBody').append("<img src="+img.src+" style=width:100%>");
                    if(i==newData.binaryResult.length-1){
                        $(".loader").css("visibility","hidden");
                        
                       
                       
                    }
                    
                }
               
            }
        });
        
    });*/
    
   $(".downloadBtn").click(function(){
        var fileName = $('.downloadBtn').attr('name');
        $(".word-content").wordExport(fileName);
    });
	
    
     $('#testCaseTable').on('click','a', function(){
		
        var testId = $(this).parent('td').attr("id");
      //  alert('You clicked row '+ testId );
         $.ajax({
             url : "/"+testId+"/testcase",
             type : "POST",
             data : {test:testId},
             dataType : "json",
             success : function(testData){
                 $('#myModal').modal('show');
                 $('#modalTable').empty();
                 for(var i=0;i<testData.testResult[0].children.length;i++){
                     //console.log(testData.testResult[0].children[i].name+"    "+testData.testResult[0].children[i].status);
                     if(testData.testResult[0].children[i].result=="" ||testData.testResult[0].children[i].result==undefined){
                         testData.testResult[0].children[i].result="Not Run";
                          $('#modalTable').append("<tr><td>"+(i+1)+"</td><td>"+testData.testResult[0].children[i].name+"</td><td>"+testData.testResult[0].children[i].result+"</td></tr>");
                     }else{
                         $('#modalTable').append("<tr><td>"+(i+1)+"</td><td>"+testData.testResult[0].children[i].name+"</td><td>"+testData.testResult[0].children[i].result+"</td></tr>");
                     }
                    
                 }
             }
         });
        
});

    
    
    
    

}); //end of document file