var executionListHeaders = [
    "Project Name",
    "Execution Name",
    "Execution Time",
    "TestSet Name",
    "Tags",
    "UserID",
    "Emails",
    "Retry Count",
    "Pull Latest",
    "Ignore ScreenShot",
    "Machine Name"
];

var dataForVariable = [];

function makeTable(container, thead, data, type) {
    thead.empty();
    container.empty();
    for (var i = 0; i < executionListHeaders.length; i++) {
        var th = $("<th>" + executionListHeaders[i] + "</th>");
        thead.append(th);
    }
    if (type == 'noData') {
        console.log("Adwqd");
        thead.append($("<th></th><th >Operation</th>"));
        container.append(thead);
        $('#executionTable').append($("<center class='noData' style='margin-left:50px;font-size:25px;opacity:0.2;font-style:italic;border:none'>No Data To Show</center>"));
    } else {
        $('#executionTable').find('.noData').remove();

        var tablebody = $("<tbody id='executionTableBody'></tbody>");
        if (type == "Expired") {
            thead.append($("<td></td><td>Status</td>"));
            if (data.length == 0)
                $('#executionTable').append($("<center class='noData' style='margin-left:50px;font-size:25px;opacity:0.2;font-style:italic;border:none'>No Data To Show</center>"));
        } else {
            thead.append($("<td></td><td >Operation</td>"));
            if (data.length == 0)
                $('#executionTable').append($("<center class='noData' style='margin-left:50px;font-size:25px;opacity:0.2;font-style:italic;border:none'>No Data To Show</center>"));
        }
        for (var i = 0; i < data.length; i++) {
            var row = $("<tr id='" + data[i]._id + "'></tr>");
            row.append($("<td></td>").text(data[i].projectName));
            row.append($("<td></td>").text(data[i].executionName));
            row.append($("<td style='width:150px;'></td>").text(new Date(data[i].executionTime * 1000).toLocaleDateString() + " " + new Date(data[i].executionTime * 1000).toLocaleTimeString()));
            row.append($("<td></td>").text(data[i].testSetName));
            row.append($("<td></td>").text(data[i].tagsList));
            row.append($("<td></td>").text(data[i].userID));
            if (data[i].emails.length > 1) {
                row.append($("<td style='width:30%;'></td>").text(data[i].emails[0] + "..."));
            } else {
                row.append($("<td  style='width:150px;'></td>").text(" No Emails"));
            }
            row.append($("<td></td>").text(data[i].retryCount));
            row.append($("<td></td>").text(data[i].pullLatest));
            row.append($("<td></td>").text(data[i].ignoreScreenShot));
            row.append($("<td></td>").text(data[i].machineName));
            console.log("-----------" + data[i].executionTime);
            console.log(new Date().getTime());
            if (type == "Expired" || (data[i].executionTime * 1000) < new Date().getTime()) {
                row.append($("<td></td>"));
                row.append($("<td></td>").append($("<span class='badge badge-danger'>Expired</span>")));
            } else {
                row.append($("<td></td>").append($("<button class='w3-btn btn-info updateBtn'>Update</button>")));
                row.append($("<td></td>").append($("<button class='w3-btn btn-danger delete '>Delete</button>")));
            }
            tablebody.append(row);
        }
        container.append(thead);
        container.append(tablebody);


    }
    return container;
}

function showLatestExecutionInTable(data) {

    var row = $("<tr id='" + data.latestRecord[0]._id + "'></tr>");
    row.append($("<td></td>").text(data.latestRecord[0].projectName));
    row.append($("<td></td>").text(data.latestRecord[0].executionName));
    row.append($("<td></td>").text(new Date(data.latestRecord[0].executionTime * 1000).toLocaleDateString() + " " + new Date(data.latestRecord[0].executionTime * 1000).toLocaleTimeString()));
    row.append($("<td></td>").text(data.latestRecord[0].testSetName));
    row.append($("<td></td>").text(data.latestRecord[0].tagsList));
    row.append($("<td></td>").text(data.latestRecord[0].userID));
    if (data.latestRecord[0].emails.length > 1) {
        row.append($("<td style='width:30%;'></td>").text(data.latestRecord[0].emails[0] + "..."));
    } else {
        row.append($("<td  style='width:150px;'></td>").text(" No Emails"));
    }
    row.append($("<td></td>").text(data.latestRecord[0].retryCount));
    row.append($("<td></td>").text(data.latestRecord[0].pullLatest));
    row.append($("<td></td>").text(data.latestRecord[0].ignoreScreenShot));
    row.append($("<td></td>").text(data.latestRecord[0].machineName));
    row.append($("<td></td>").append($("<button class='w3-btn btn-info updateBtn'>Update</button>")));
    row.append($("<td></td>").append($("<button class='w3-btn btn-danger delete '>Cancel</button>")));
    $("#heading").after(row);
}

function getLastCreatedExecution() {
    $('#executionTable').find('.noData').remove();
    $.ajax({
        url: "/getLatestCreatedExecution",
        type: 'POST',
        contetType: "json",
        success: function (data) {
            $("#myInput").val('');
            $('#tableByStatus').hide();
            showLatestExecutionInTable(data);
        }

    });
}


(function () {

    $('#tblVariable').hide();
    $('#sendEmails').hide();
    $('#showVariableE').hide();
    $('#update_sendEmails').hide();
    $('#tableByStatus').hide();
    $('#variables_IDE').prop("disabled", true);
    $('#variableRow').empty();
    $.ajax({
        url: "/getAllJobs",
        type: "POST",
        dataType: "json",
        success: function (data) {
            if (data.jobs.length > 0) {
                console.log(data.jobs.length);
                makeTable($('#executionListTable'), $('#heading'), data.jobs, "");
            } else {
                console.log("NO data to show");
                makeTable($('#executionListTable'), $('#heading'), data, "noData");
            }
        }
    });

    $("#myInput").val('');
    $("#myInput").on("keyup", function () {
        var value = $(this).val().toLowerCase();
        $("#executionListTable tr").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });



    var defualt = loadFormData("create", ' ');
    $('#modalCreateExecution').on('shown.bs.modal', function (e) {
        loadProjectBasedDataforCreation();
    });




    $('#submitExecution').click(function () {
        $.confirm({
            title: 'Execution Confirmation',
            content: 'Sure You want to create Execution',
            type: 'blue',
            buttons: {
                ok: {
                    text: "ok!",
                    btnClass: 'btn-primary',
                    keys: ['enter'],
                    action: function () {
                        $.ajax({
                            type: 'POST',
                            url: '/scheduleJob',
                            data: $('#scheduleJobForm').serialize(),
                            cache: false
                        }).done(function (rcvdata) {
                            if (rcvdata.result.ok == 1) {
                                $('#scheduleJobForm').trigger('reset');
                                $('#modalCreateExecution').modal('hide');
                                getLastCreatedExecution();
                            }
                        });
                    }
                },
                cancel: function () {
                    $('#modalCreateExecution').modal('show');
                }
            }

        });
        
    });



})();

function loadFormData(type, dataToMatch) {
    $.ajax({
        url: "/getProjectName",
        type: "POST",
        dataType: "json",
        success: function (data) {
            if (type == "create") {
                $("#tableByProject").empty();
                $("#tableByProject").append($("<option></option>").html("Choose a project"));
                for (var i = 0; i < data.projectName.length; i++) {
                    $("#tableByProject").append($("<option></option>").val(data.projectName[i].name).html(data.projectName[i].name));
                    $("#project_id").append($("<option></option>").val(data.projectName[i].name).html(data.projectName[i].name));
                }
            }
            if (type == "update") {
                $("#update_project_id").empty();

                $("#update_project_id").append($("<option></option>").html("Choose a project"));
                for (var i = 0; i < data.projectName.length; i++) {

                    if (dataToMatch.projectName == data.projectName[i].name)
                        $("#update_project_id").append($("<option selected='true'></option>").val(data.projectName[i].name).html(data.projectName[i].name));
                    else
                        $("#update_project_id").append($("<option></option>").val(data.projectName[i].name).html(data.projectName[i].name));
                }
            }
        }
    });

}

$('select#tableByProject').change(function () {
    $("#myInput").empty();

    $.ajax({
        url: "/getExecutionByProjectName",
        type: "POST",
        data: {
            project: $(this).val()
        },
        dataType: "json",
        success: function (data) {
            console.log(data.result.length);
            if (data.result.length > 0) {

                $('#tableByStatus').show();
                makeTable($('#executionListTable'), $('#heading'), data.result, " ");
                $("#myInput").show();
                $("#myInput").val('');
                $('select#tableByStatus').change(function () {
                    $("#myInput").val('');
                    $.ajax({
                        url: "/getExecutionByStatus",
                        type: "POST",
                        data: {
                            status: $(this).val(),
                            projectName: data.result[0].projectName
                        },
                        dataType: "json",
                        success: function (data) {
                            console.log(data.status);
                            if (data.result != " " && data.status == "Expired")
                                makeTable($('#executionListTable'), $('#heading'), data.result, "Expired");
                            else
                                makeTable($('#executionListTable'), $('#heading'), data.result, "Scheduled");
                        }
                    });

                });
            } else {
                $('#tableByStatus').hide();
                $('#executionTableBody').empty();
                $('#executionTable').find('.noData').remove();
                $("#myInput").hide();
                $("#myInput").val('');
                $('#executionTable').append($("<center class='noData' style='margin-left:50px;font-size:25px;opacity:0.2;font-style:italic;border:none'>No Data To Show</center>"));
            }
        }
    });

});


function addVarToVariableTable(selectedVar, data) {
    var row = $("<tr style='width:150px;height:50px;'></tr>");
    var input = $("<input class='form-control varName' type='text' name='variableNameList'  value='" + selectedVar.val() + "'  readonly/></td>");
    var td = $("<td></td>");
    $('#tblVariable').show();
    td.append(input);
    row.append(td);
    for (var i = 0; i < data.length; i++) {

        if (data[i].name == selectedVar.val()) {
            addValToVariableTable(row, data[i].value, data[i].possibleValues);
        }
    }
    selectedVar.remove();
    if ($('#varList').has('option').length == 0)
        $('#variableName').hide();
}

function addValToVariableTable(row, value, possibleValues) {
    if (possibleValues.length > 0 && value != "") {
        console.log(value);
        console.log(possibleValues);
        var select = $("<select class='form-control' name='variableValueList'><option selected='true' disabled='disabled'>Choose Value</option></select>");
        for (var i = 0; i < possibleValues.length; i++) {
            console.log(possibleValues.length);
            console.log(possibleValues[i]);
            select.append($("<option></option>").val(possibleValues[i]).html(possibleValues[i]));
        }
        var td = $("<td></td>");
        td.append(select);
        row.append(td);
    } else
        row.append($("<td><input class='form-control' type='text' name='variableValueList' value='" + value + "'/></td>"));

    row.append($("<td><span  class='glyphicon glyphicon-minus deleteRow'></span></td>"));
    $('#variableRow').append(row);
}



function loadProjectBasedDataforCreation() {
    $('select#project_id').change(function () {
        $('#tblVariable').hide();
        $('#variables_IDE').prop("disabled", false);
        $.ajax({
            url: "/getTestSet",
            type: "POST",
            data: {
                project: $(this).val()
            },
            dataType: "json",
            success: function (data) {
                $("#testSet_id").empty();
                $("#testSet_id").append($("<option selected='true' disabled='disabled'></option>").html("Choose a TestSet"));
                for (var i = 0; i < data.testSetName.length; i++) {
                    console.log(data.testSetName[i].name);
                    $("#testSet_id").append($("<option></option>").val(data.testSetName[i].name).html(data.testSetName[i].name));
                }

            }
        });

        $.ajax({
            url: "/getVariables",
            type: "POST",
            data: {
                projectName: $(this).val()
            },
            dataType: "json",
            success: function (data) {
                if (data.varResult != "") {
                    $('#varList').empty();
                    dataForVariable = [];
                    dataForVariable = data.varResult;
                    for (var i = 0; i < data.varResult.length; i++) {
                        $('#varList').append($("<option></option>").val(data.varResult[i].name).html(data.varResult[i].name));
                    }

                }

            }

        });


        $('#addSelectedVar').click(function () {
            addVarToVariableTable($('#varList :selected'), dataForVariable);
        });

        $.ajax({
            url: "/getMachines",
            type: "POST",
            dataType: "json",
            success: function (data) {
                $("#machine_id").empty();
                $("#machine_id").append($("<option selected='true' disabled='disabled'></option>").html("Choose a Machine"));
                for (var i = 0; i < data.machines.length; i++) {
                    //console.log(data.machines[i].description);
                    if (data.machines[i].description != "") {
                        var machineName = data.machines[i].description.split(":");
                        $("#machine_id").append($("<option></option>").val(data.machines[i].host).html(machineName[1] + "(" + data.machines[i].host + ")"));
                    }
                }
            }
        });

        $.ajax({
            url: "/getUsers",
            type: "POST",
            dataType: "json",
            success: function (data) {
                $("#userID").empty();
                $("#userID").append($("<option selected='true' disabled='disabled'></option>").html("Choose a User"));
                for (var i = 0; i < data.users.length; i++) {
                    if (data.users[i].username != "admin") {
                        $("#userID").append($("<option></option>").val(data.users[i].username).html(data.users[i].name + "  (" + data.users[i].username + ")"));
                    }
                }
            }
        });

    });


    $('#sendEmail').change(function () {
        var $check = $(this);
        if ($check.prop('checked')) {
            $('#sendEmails').show();
            $(this).val('True');
            $.ajax({
                url: "/getEmails",
                type: "POST",
                dataType: "json",
                success: function (data) {
                    $("#emailIDs").empty();
                    $("#emailIDs").append($("<option selected='true' disabled='disabled'></option>").html("Choose Emails"));
                    for (var i = 0; i < data.emails.length; i++) {
                        $("#emailIDs").append($("<option></option>").val(data.emails[i].email).html(data.emails[i].name));
                    }
                }
            });
        } else {
            $('#sendEmails').hide();
            $("#emailIDs").empty();
        }
    });

    if ($('#ignoreScreeShotID').prop('checked')) {
        $('#ignoreScreeShotID').val('True');
    } else
        $('#ignoreScreeShotID').val('False');





    $('#variables_IDE').click(function () {
        $('#showVariableE').show();

    });
    $('#pullcbxID').change(function () {
        var $check = $(this);
        if ($check.prop('checked')) {
            $(this).val('True');
        } else {

            $(this).val('False');
        }
    });

    $('#ignoreScreeShotID').change(function () {
        var $check = $(this);
        if ($check.prop('checked')) {
            $(this).val('True');
        } else {

            $(this).val('False');
        }
    });

    $('#tblVariable').on('click', 'span.deleteRow', function () {
        var delRow = $(this).parent().parent();
        var varNameDeleted = delRow.find('input.varName').val();
        console.log(varNameDeleted);
        $.confirm({
            title: 'Variable Deletion',
            content: 'Sure You want to Delete Variable',
            type: 'red',
            buttons: {
                ok: {
                    text: "ok!",
                    btnClass: 'btn-primary',
                    keys: ['enter'],
                    action: function () {
                        delRow.remove();
                        $('#varList').append($("<option></option>").val(varNameDeleted).html(varNameDeleted));
                        $('#variableName').show();
                    }
                },
                cancel: function () {

                }

            }

        });

    });

}

function convertToArray(data) {
    var array = [];
    if (Array.isArray(data))
        return data;
    else {

        array.push(data);
        return array;
    }
}

function addVarToVariableUpdateTable(selectedVar, data) {
    var row = $("<tr></tr>");
    row.append($("<td ><input class='form-control form-control-sm update_varName' type='text' name='update_variableNameList'  value='" + selectedVar.val() + "' readonly /></td>"));
    $('#update_tblVariable').show();
    for (var i = 0; i < data.length; i++) {

        if (data[i].name == selectedVar.val()) {
            addValToVariableUpdateTable(row, data[i].value, data[i].possibleValues);
        }
    }
    selectedVar.remove();
    if ($('#update_varList').has('option').length == 0)
        $('#update_variableName').hide();
}

function addValToVariableUpdateTable(row, value, possibleValues) {
    if (possibleValues.length > 0 && value != "") {
        var select = $("<select class='form-control form-control-sm' name='update_variableValueList'><option selected='true' disabled='disabled'>Choose Value</option></select>");
        for (var i = 0; i < possibleValues.length; i++) {
            select.append($("<option></option>").val(possibleValues[i]).html(possibleValues[i]));
        }
        var td = $("<td></td>");
        td.append(select);
        row.append(td);
    } else
        row.append($("<td><input class='form-control form-control-sm' type='text' name='update_variableValueList' value='" + value + "'/></td>"));

    row.append($("<td><span data-feather='minus-square' class='deleteRow'></span></td>"));
    $('#update_variableRow').append(row);
}


function loadDataForVaiableUpdate(selectedProjectName) {
    $.ajax({
        url: "/getVariables",
        type: "POST",
        data: {
            projectName: selectedProjectName
        },
        dataType: "json",
        success: function (data) {
            if (data.varResult != "") {
                $('#update_varList').empty();
                dataForVariable = [];
                dataForVariable = data.varResult;
                for (var i = 0; i < data.varResult.length; i++) {
                    $('#update_varList').append($("<option></option>").val(data.varResult[i].name).html(data.varResult[i].name));
                }

            }

        }

    });


    $('#update_addSelectedVar').click(function () {
        addVarToVariableUpdateTable($('#update_varList :selected'), dataForVariable);
    });
}

function loadProjectBasedDataforUpdate(dataToMatch) {
    $('#update_showVariable').hide();
    $('.formClass').remove();
    $('<input>').attr({
        class: 'formClass',
        type: 'hidden',
        name: 'formID',
        value: dataToMatch._id
    }).appendTo('#updateJobForm');
    $('#update_execution_name_id').val(dataToMatch.executionName);
    console.log(new Date(dataToMatch.executionTime * 1000).toLocaleDateString() + " " + new Date(dataToMatch.executionTime * 1000).toLocaleTimeString());
    $('#update_datetimepicker-default').val(new Date(dataToMatch.executionTime * 1000).toLocaleDateString() + " " + new Date(dataToMatch.executionTime * 1000).toLocaleTimeString());
    $('#update_tagID').empty();
    var tagArray = dataToMatch.tagsList.split(",");
    var tagToDisplay = "";
    for (var i = 0; i < tagArray.length; i++) {
        tagToDisplay += tagArray[i] + " ";
    }
    $('#update_tagID').val(tagToDisplay);
    $('#update_retry_count').val(dataToMatch.retryCount);
    if (dataToMatch.emails.length > 1) {
        $("#update_sendEmail").prop("checked", true);
        $('#update_sendEmails').show();
        $.ajax({
            url: "/getEmails",
            type: "POST",
            dataType: "json",
            success: function (data) {
                $("#update_emailIDs").empty();
                $("#update_emailIDs").append($("<option  disabled='disabled'></option>").html("Choose Emails"));
                var emailNameList = [];
                var emailValueList = [];
                for (var i = 0; i < data.emails.length; i++) {
                    emailNameList.push(data.emails[i].name);
                    emailValueList.push(data.emails[i].email);
                }
                for (var j = 0; j < dataToMatch.emails.length; j++) {
                    var index = emailValueList.indexOf(dataToMatch.emails[j]);
                    if (index > -1) {
                        $("#update_emailIDs").append($("<option selected='true'></option>").val(emailValueList[index]).html(emailNameList[index]));

                    }

                }
                for (var i = 0; i < emailValueList.length; i++) {
                    var index = dataToMatch.emails.indexOf(emailValueList[i]);
                    if (index > -1) {} else
                        $("#update_emailIDs").append($("<option></option>").val(emailValueList[i]).html(emailNameList[i]));
                }

            }
        });
    } else {
        $("#update_sendEmail").prop("checked", false);
        $('#update_sendEmails').hide();
    }


    $('select#update_project_id').change(function () {
        $.ajax({
            url: "/getTestSet",
            type: "POST",
            data: {
                project: $(this).val()
            },
            dataType: "json",
            success: function (data) {

                $("#update_testSet_id").empty();
                $("#update_testSet_id").append($("<option disabled='disabled'></option>").html("Choose a TestSet"));
                for (var i = 0; i < data.testSetName.length; i++) {

                    if (data.testSetName[i].name == dataToMatch.testSetName) {
                        $("#update_testSet_id").append($("<option selected='true'></option>").val(data.testSetName[i].name).html(data.testSetName[i].name));
                    } else
                        $("#update_testSet_id").append($("<option></option>").val(data.testSetName[i].name).html(data.testSetName[i].name));


                }


            }
        });
        loadDataForVaiableUpdate($(this).val());
    });


    $.ajax({
        url: "/getMachines",
        type: "POST",
        dataType: "json",
        success: function (data) {
            $("#update_machine_id").empty();
            $("#update_machine_id").append($("<option disabled='disabled'></option>").html("Choose a Machine"));
            for (var i = 0; i < data.machines.length; i++) {
                if (data.machines[i].description != "") {
                    var machineName = data.machines[i].description.split(":");
                    if (machineName[1] == dataToMatch.machineName)
                        $("#update_machine_id").append($("<option selected='true'></option>").val(data.machines[i].host).html(machineName[1]));
                    else
                        $("#update_machine_id").append($("<option></option>").val(data.machines[i].host).html(machineName[1] + "(" + data.machines[i].host + ")"));
                }
            }
        }
    });

    $.ajax({
        url: "/getUsers",
        type: "POST",
        dataType: "json",
        success: function (data) {
            $("#update_userID").empty();
            $("#update_userID").append($("<option selected='true' disabled='disabled'></option>").html("Choose a User"));
            for (var i = 0; i < data.users.length; i++) {
                if (data.users[i].username != "admin") {
                    if (data.users[i].username == dataToMatch.userID)
                        $("#update_userID").append($("<option selected='true'></option>").val(data.users[i].username).html(data.users[i].name + "  (" + data.users[i].username + ")"));
                    else
                        $("#update_userID").append($("<option></option>").val(data.users[i].username).html(data.users[i].name + "  (" + data.users[i].username + ")"));
                }
            }
        }
    });




    $('#update_sendEmail').change(function () {
        var $check = $(this);
        if ($check.prop('checked')) {
            $('#update_sendEmails').show();
            $(this).val('True');
            $.ajax({
                url: "/getEmails",
                type: "POST",
                dataType: "json",
                success: function (data) {
                    $("#update_emailIDs").empty();
                    $("#update_emailIDs").append($("<option selected='true' disabled='disabled'></option>").html("Choose Emails"));
                    for (var i = 0; i < data.emails.length; i++) {
                        $("#update_emailIDs").append($("<option></option>").val(data.emails[i].email).html(data.emails[i].name));
                    }
                }
            });

        } else {
            $('#update_sendEmails').hide();
            // $("#update_emailIDs").empty();
        }
    });

    if (dataToMatch.ignoreScreenShot == "True") {
        $('#update_ignoreScreeShotID').prop('checked', true);
        $('#update_ignoreScreeShotID').val('True');
    } else {
        $('#update_ignoreScreeShotID').prop('checked', false);
        $('#update_ignoreScreeShotID').val('False');
    }

    if (dataToMatch.pullLatest == "True") {
        $('#update_pullcbxID').prop('checked', true);
        $('#update_pullcbxID').val('True');
    } else {
        $('#update_pullcbxID').prop('checked', false);
        $('#update_pullcbxID').val('False');
    }

    if ($('#update_ignoreScreeShotID').prop('checked')) {
        $('#update_ignoreScreeShotID').val('True');
    } else
        $('#update_ignoreScreeShotID').val('False');

    $('#update_variables_ID').click(function () {
        $('#update_showVariable').show();
    });

    $('#update_pullcbxID').change(function () {
        var $check = $(this);
        if ($check.prop('checked')) {
            $(this).val('True');
        } else {

            $(this).val('False');
        }
    });

    $('#update_ignoreScreeShotID').change(function () {
        var $check = $(this);
        if ($check.prop('checked')) {
            $(this).val('True');
        } else {

            $(this).val('False');
        }
    });

    $('#update_tblVariable').on('click', 'span.update_deleteRow', function () {
        var delRow = $(this).parent().parent();
        var varNameDeleted = delRow.find('input.update_varName').val();
        console.log(varNameDeleted);
        $.confirm({
            title: 'Variable Deletion',
            content: 'Sure You want to Delete Variable',
            type: 'red',
            buttons: {
                ok: {
                    text: "ok!",
                    btnClass: 'btn-primary',
                    keys: ['enter'],
                    action: function () {
                        delRow.remove();
                        $('#update_varList').append($("<option></option>").val(varNameDeleted).html(varNameDeleted));
                        $('#update_variableName').show();
                    }
                },
                cancel: function () {

                }

            }

        });

    });

}


$(document).ready(function () {

    $('table').on('click', 'button.updateBtn', function () {
        var rowID = $(this).parent().parent().attr('id');
        $.ajax({
            type: 'POST',
            url: '/getRecordforUpdate',
            data: {
                id: rowID
            },
            success: function (data) {
                console.log(data.recToUpdate);
                $('#modalUpdateExecution').modal('show');
                $('#updateJobForm').trigger('reset');
                loadFormData("update", "dataToMatch");
                loadProjectBasedDataforUpdate(data.recToUpdate[0]);
            }

        });


    });



    $('#updateExecutionBtn').click(function () {
        $.confirm({
            title: 'Update Confirmation',
            content: 'Sure You want to Update Execution',
            type: 'blue',
            buttons: {
                ok: {
                    text: "ok!",
                    btnClass: 'btn-primary',
                    keys: ['enter'],
                    action: function () {
                        $.ajax({
                            type: 'POST',
                            url: '/updateRecord',
                            data: $('#updateJobForm').serialize(),
                            cache: false
                        }).done(function (rcvdata) {
                            if (rcvdata.msg.ok == 1) {
                                $('#updateJobForm').trigger('reset');
                                $('#modalUpdateExecution').modal('hide');
                                $('table#executionListTable tr#' + rcvdata.updateID).remove();
                                getLastCreatedExecution();


                            }
                        });
                    }
                },
                cancel: function () {
                    $('#modalUpdateExecution').modal('show');
                }
            }

        });
    });

    $('table').on('click', 'button.delete', function () {
        var rowID = $(this).parent().parent().attr('id');
        $.confirm({
            title: 'Delete Confirmation',
            content: 'Sure You want to Delete Execution',
            type: 'red',
            buttons: {
                ok: {
                    text: "ok!",
                    btnClass: 'btn-primary',
                    keys: ['enter'],
                    action: function () {
                        $.ajax({
                            type: 'POST',
                            url: '/deleteExecution',
                            data: {
                                id: rowID
                            },
                            success: function (data) {
                                if (data.delResponse.n == 1) {
                                    $('table#executionListTable tr#' + rowID).remove();
                                }
                            }
                        });
                    }
                },
                cancel: function () {

                }
            }

        });

    });

});
$(document).ready(function () {

    var offset = 250;

    var duration = 300;

    $(window).scroll(function () {

        if ($(this).scrollTop() > offset) {

            $('.back-to-top').fadeIn(duration);

        } else {

            $('.back-to-top').fadeOut(duration);

        }

    });

    $('.back-to-top').click(function (event) {

        event.preventDefault();

        $('html, body').animate({
            scrollTop: 0
        }, duration);

        return false;

    })
});