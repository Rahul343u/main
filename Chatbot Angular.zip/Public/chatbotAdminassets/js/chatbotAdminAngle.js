myApp.controller("chatAdminController", function($scope,$http){
          $scope.myLearnings ='';
        $http.get("/trainerRole").then(function(response) {
        $scope.userRoleFlag = response.data.role;
              });
        $http.get("/userlist").then(function(response) {
          $scope.adminlist = response.data.admin;
          $scope.trainerlist = response.data.trainer;
              });

 $scope.addadmin = function()
{
  var data =  {
      username: $scope.AdminID.toLowerCase(),
      role: "admin"
    };
    var config = {
            headers : {
                'Content-Type': 'application/json'
            }
        }
        $http.post("/addadmin" , data , config).then(function (data, status, headers, config) {
          $scope.adminlist = data.data.admin;
          $scope.AdminID = '';
      });

};

$scope.removeadmin = function(admin)
{
 var data =  {
     _id: admin,
   };
   var config = {
           headers : {
               'Content-Type': 'application/json'
           }
       }
       $http.post("/removeadmin" , data , config).then(function (data, status, headers, config) {
         $scope.adminlist = data.data.admin;
     });

};


$scope.addtrainer = function()
{
 var data =  {
     username: $scope.trainerID.toLowerCase(),
     role: "trainer"
   };
   var config = {
           headers : {
               'Content-Type': 'application/json'
           }
       }
       $http.post("/addtrainer" , data , config).then(function (data, status, headers, config) {
         $scope.trainerlist = data.data.trainer;
         $scope.trainerID = '';
     });

};

$scope.removetrainer = function(trainer)
{
var data =  {
    _id: trainer,
  };
  var config = {
          headers : {
              'Content-Type': 'application/json'
          }
      }
      $http.post("/removetrainer" , data , config).then(function (data, status, headers, config) {
        $scope.trainerlist = data.data.trainer;
    });

};
$scope.loadLearningstoUpdate = function(){
  $http.get("/getMyLearnings").then(function(response) {
          $scope.myLearnings = response.data.myLearnings;

        });
};
$scope.removelearning = function()
{
var data =  {
    _id: $scope.learningIDtobeDeleted,
  };
  var config = {
          headers : {
              'Content-Type': 'application/json'
          }
      }
      $http.post("/removelearning" , data , config).then(function (data, status, headers, config) {
        $http.get("/getMyLearnings").then(function(response) {
                $scope.myLearnings = response.data.myLearnings;
                var trainingRequestmodal = document.getElementById('deleteLearningConfirmation');
                trainingRequestmodal.style.display = "none";
              });
    });

};
$scope.updatelearning = function(learntoupdate){
          $scope.querytoupdate = learntoupdate.query;
          $scope.answertoupdate = learntoupdate.answer;
          $scope.linktoupdate = learntoupdate.link;
          $scope.linktagtoupdate = learntoupdate.linktag;
          $scope.tag1toupdate = learntoupdate.tag1;
          $scope._idtoupdate = learntoupdate._id;
          var updateRequestmodal = document.getElementById('UpdateLearning');
          updateRequestmodal.style.display = "block";
};

$scope.updatelearningSubmit = function(){
  if($scope.querytoupdate && $scope.answertoupdate){
  var data =  {
      _id: $scope._idtoupdate
    };
    var config = {
            headers : {
                'Content-Type': 'application/json'
            }
        }
        $http.post("/removelearning" , data , config).then(function (data, status, headers, config) {
                });
                var data1 =  {
                    query: $scope.querytoupdate.toLowerCase(),
                    answer: $scope.answertoupdate,
                    tag1: $scope.tag1toupdate,
                    link: $scope.linktoupdate,
                    linktag:$scope.linktagtoupdate,
                    status: "pending"
                  };
                       $http.post("/trainChappie" , data1 , config).then(function (data, status, headers, config) {
                         $http.get("/getMyLearnings").then(function(response) {
                                 $scope.myLearnings = response.data.myLearnings;
                                 var updateRequestmodal = document.getElementById('UpdateLearning');
                                 updateRequestmodal.style.display = "none";
                               });

                       });

      }
};

$scope.updateLearningCancel = function(){
var updateRequestmodal = document.getElementById('UpdateLearning');
updateRequestmodal.style.display = "none";
};

$scope.deleteLearningConfirmationmodal = function(learning){
  $scope.learningIDtobeDeleted = learning;
 var deleteRequestmodal = document.getElementById('deleteLearningConfirmation');
 deleteRequestmodal.style.display = "block";
};

$scope.deleteLearningConfirmationmodalCancel = function(){
var deleteRequestmodal = document.getElementById('deleteLearningConfirmation');
deleteRequestmodal.style.display = "none";
};


$scope.loadLearningstoapprove = function(){
  $http.get("/getMyPendingLearnings").then(function(response) {
          $scope.mypendingLearnings = response.data.myLearnings;

        });
};

$scope.discardLearningConfirmationmodal = function(learning){
  $scope.learningIDtobeDiscarded = learning;
 var deleteRequestmodal = document.getElementById('discardLearningConfirmation');
 deleteRequestmodal.style.display = "block";
};

$scope.discardLearningConfirmationmodalCancel = function(){
var deleteRequestmodal = document.getElementById('discardLearningConfirmation');
deleteRequestmodal.style.display = "none";
};


$scope.Discardlearning = function()
{
var data =  {
    _id: $scope.learningIDtobeDiscarded,
  };
  var config = {
          headers : {
              'Content-Type': 'application/json'
          }
      }
      $http.post("/removelearning" , data , config).then(function (data, status, headers, config) {
        $http.get("/getMyPendingLearnings").then(function(response) {
                $scope.mypendingLearnings = response.data.myLearnings;
                var trainingRequestmodal = document.getElementById('discardLearningConfirmation');
                trainingRequestmodal.style.display = "none";
              });
    });

};

$scope.approveLearning = function(id)
{
var data =  {
    _id:id,
  };
  var config = {
          headers : {
              'Content-Type': 'application/json'
          }
      }
      $http.post("/approveLearning" , data , config).then(function (data, status, headers, config) {
        $http.get("/getMyPendingLearnings").then(function(response) {
                $scope.mypendingLearnings = response.data.myLearnings;
              });
    });

};

$scope.aaproveallLearnings = function()
{
      $http.post("/aaproveallLearnings").then(function (data) {
        $http.get("/getMyPendingLearnings").then(function(response) {
                $scope.mypendingLearnings = response.data.myLearnings;
                var trainingRequestmodal = document.getElementById('aaproveallLearningsConfirmation');
                trainingRequestmodal.style.display = "none";
              });
    });

};



$scope.aaproveallLearningsConfirmation = function(learning){
  $scope.learningIDtobeDiscarded = learning;
 var deleteRequestmodal = document.getElementById('aaproveallLearningsConfirmation');
 deleteRequestmodal.style.display = "block";
};

$scope.aaproveallLearningsConfirmationCancel = function(){
var deleteRequestmodal = document.getElementById('aaproveallLearningsConfirmation');
deleteRequestmodal.style.display = "none";
};


  });


   // Get the modal
 var modal = document.getElementById('deleteLearningConfirmation');

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
      if (event.target == modal) {
          modal.style.display = "none";
      }

};
