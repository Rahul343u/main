var ObjectId = require('mongodb').ObjectID;
var randomInt = require('random-int');
module.exports = function (app,dbs){

  app.post('/chappie',function (req,response)
       {
         if((req.body.query.indexOf("hi") !== -1) || (req.body.query.indexOf("hello") !== -1) || (req.body.query.indexOf("hey") !== -1)
      || (req.body.query.indexOf("hola") !== -1)||(req.body.query.indexOf("hellow") !== -1)){
           switch (randomInt(6)) {
    case 0:
        ans =[{answer:'Hi '+req.session.user+', Great to see you ! How may I help you ?'}]
        break;
    case 1:
      ans =[{answer:'Hello '+req.session.user+', nice to see you ! How may I assist you ?'}]
        break;
    case 2:
      ans =[{answer:'Hey '+req.session.user+', How are you doing ?'}]
        break;
    case 3:
      ans =[{answer:'Hola '+req.session.user+', You seems happy today, How may I help you ?'}]
        break;
    case 4:
        ans =[{answer:'Namaste '+req.session.user+', Great to see you ! What can I do for you ?'}]
        break;
    case 5:
      ans =[{answer:'Good to see you '+req.session.user+', How may I help you ?'}]
        break;
    case  6:
        ans =[{answer:'Hi '+req.session.user+', Great to see you ! What can I do for you ?'}]
}
            response.send({data:ans});
         }

else if((req.body.query.indexOf("bye") !== -1)){
  switch (randomInt(4)) {
  case 0:
  ans =[{answer:'Bye '+req.session.user+', Have a Great Day !!'}]
  break;
  case 1:
  ans =[{answer:'Bye-Bye '+req.session.user+', It was nice to see you !' }]
  break;
  case 2:
  ans =[{answer:'Bye '+req.session.user+', Hope to see you soon !'}]
  break;
  case 3:
  ans =[{answer:'Bye '+req.session.user+', Take Care !!'}]
  break;
  case 4:
  ans =[{answer:'Bye '+req.session.user+', Please Come Back When ever you have any query !!'}]
  }
   response.send({data:ans});

}

         else{
dbs.taffybot.collection("chappie").find({"query":{ $regex :req.body.query } },{}).toArray(function(err, ans)
                    {
                      if (err) throw err;
                      if(ans[0] !== undefined){
                         response.send({data:ans});
                       }

                       if(ans[0] == undefined){
                         ans =[{answer:'Hey '+req.session.user+', Can you please help me out what you want exactly ?',
                                trainingRequest : 'true',
                                trainingRequestQuery : req.body.query
                       }];
                          response.send({data:ans});
                        }
                    });
                  }
        });


        app.post('/trainChappie',function (req,response)
             {

               var data =req.body;
               console.log(data);
               dbs.taffybot.collection("chappie").insertOne(data,function(err, res) {
                 if (err) throw err;
     ans =[{answer:'Thank you for Teaching me this '+"'"+req.body.query+"'"}]
      response.send({data:ans});

  });

    });
    app.get('/adminPannel',function (req,response)
         {
           response.render('chatbotAdmin');
  });

  app.get('/trainingPannel',function (req,response)
       {
                  response.render('chatbotAdmin');

});


app.get('/trainerRole',function (req,response)
       {
         if(req.session.username != undefined){
      dbs.taffybot.collection("botUsers").find({"username":req.session.username.toLowerCase()},{role:1}).toArray(function(err,role){
         if (err) throw err;

         console.log(role);
      if(role[0] == null){
          response.send({role:'user'});
       }
       else{

         response.send({role:role[0].role});
       }
      });
    }else {
    response.send({role:'user'});
    }
  });

  app.get('/userlist',function (req,response)
         {
  dbs.taffybot.collection("botUsers").find({role:"admin"},{username:1}).toArray(function(err,adminlist){
  if (err) throw err;
     dbs.taffybot.collection("botUsers").find({role:"trainer"},{username:1}).toArray(function(err,trainerlist){
     if (err) throw err;
          response.send({admin:adminlist,trainer:trainerlist});
   });
});
});

app.post('/addadmin',function (req,response)
     {
       var data =req.body;
       dbs.taffybot.collection("botUsers").insertOne(data,function(err, res) {
         if (err) throw err;

         dbs.taffybot.collection("botUsers").find({role:"admin"},{username:1}).toArray(function(err,adminlist){
         if (err) throw err;
        response.send({admin:adminlist});
});
 });
});

app.post('/removeadmin',function (req,response)
     {
       var data =req.body;
       dbs.taffybot.collection("botUsers").remove({_id:ObjectId(data._id)},function(err, res) {
         if (err) throw err;

         dbs.taffybot.collection("botUsers").find({role:"admin"},{username:1}).toArray(function(err,adminlist){
         if (err) throw err;
        response.send({admin:adminlist});
});
 });
});


app.post('/addtrainer',function (req,response)
     {
       var data =req.body;
       dbs.taffybot.collection("botUsers").insertOne(data,function(err, res) {
         if (err) throw err;

         dbs.taffybot.collection("botUsers").find({role:"trainer"},{username:1}).toArray(function(err,trainerlist){
         if (err) throw err;
        response.send({trainer:trainerlist});
});
 });
});

app.post('/removetrainer',function (req,response)
     {
       var data =req.body;
       dbs.taffybot.collection("botUsers").remove({_id:ObjectId(data._id)},function(err, res) {
         if (err) throw err;

         dbs.taffybot.collection("botUsers").find({role:"trainer"},{username:1}).toArray(function(err,trainerlist){
         if (err) throw err;
        response.send({trainer:trainerlist});
});
 });
});

app.post('/trainingRequest',function (req,response)
     {

       var data =req.body;
       console.log(data);
       dbs.taffybot.collection("trainingrequest").insertOne(data,function(err, res) {
         if (err) throw err;
ans =[{answer:'Thank you for your Training Request of '+"'"+req.body.query+"'"}]
response.send({data:ans});

});

});

app.get('/getTrainingRequests',function (req,response)
       {
      dbs.taffybot.collection("trainingrequest").find({},{}).toArray(function(err,trainingRequests){
         if (err) throw err;
      if(trainingRequests[0] == null){
          response.send({notrainingRequests : "true"});
       }
       else{
         response.send({trainingRequests:trainingRequests});
       }
      });

  });

  app.post('/removeFulfilledRequest',function (req,response)
       {
         var data =req.body;
         dbs.taffybot.collection("trainingrequest").remove({_id:ObjectId(data._id)},function(err, res) {
           if (err) throw err;
           ans =[{answer:'Thank you ! you have fulfilled the Training Request ID : '+"'"+req.body._id+"'"}]
           response.send({data:ans});
  });
   });
app.post('/notRelaventRequest',function (req,response)
        {
          var data =req.body;
          dbs.taffybot.collection("trainingrequest").remove({_id:ObjectId(data._id)},function(err, res) {
            if (err) throw err;
            ans =[{answer:'Thank you ! you have marked Training Request ID : '+"'"+req.body._id+"' as not Relavent"}]
            response.send({data:ans});
   });
    });
    app.post('/alreadyDonRequest',function (req,response)
            {
              var data =req.body;
              dbs.taffybot.collection("trainingrequest").remove({_id:ObjectId(data._id)},function(err, res) {
                if (err) throw err;
                ans =[{answer:'Thank you ! you have marked Training Request ID : '+"'"+req.body._id+"' as Already done"}]
                response.send({data:ans});
       });
        });


        app.get('/getMyLearnings',function (req,response)
               {
              dbs.taffybot.collection("chappie").find({},{}).toArray(function(err,myLearnings){
                 if (err) throw err;
                 response.send({myLearnings:myLearnings});

              });

          });

          app.post('/removelearning',function (req,response)
               {
                 var data =req.body;
                 dbs.taffybot.collection("chappie").remove({_id:ObjectId(data._id)},function(err, res) {
                   if (err) throw err;
                   response.send({data:res});
           });
          });

          app.get('/getMyPendingLearnings',function (req,response)
                 {
                dbs.taffybot.collection("chappie").find({status:"pending"},{}).toArray(function(err,myLearnings){
                   if (err) throw err;
                   response.send({myLearnings:myLearnings});

                });

            });

            app.post('/approveLearning',function (req,response)
                 {
                   var data =req.body;
                   dbs.taffybot.collection("chappie").updateOne({_id:ObjectId(data._id)},{ $set:{status:"approved"}},function(err, res) {
                     if (err) throw err;
                     response.send({data:res});
             });
            });
            app.post('/aaproveallLearnings',function (req,response)
                 {
                   dbs.taffybot.collection("chappie").updateMany({status:"pending"},{ $set:{status:"approved"}},function(err, res) {
                     if (err) throw err;
                     response.send({data:res});
             });
            });

  return app;
  };
