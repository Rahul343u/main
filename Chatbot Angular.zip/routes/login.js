//var express = require('express');
//var cron = require('node-cron');
//var path = require('path');
//var bodyParser = require('body-parser');
//var app = express();
//var loginRouter = express.Router();
//var MongoClient = require('mongodb').MongoClient;
var ldap = require('ldapjs');
var ldap_server = '10.10.80.1';
var session = require('express-session');





module.exports=function(app,dbs){
	app.get('/', function (req, res) {
		res.render('login',{divcss:"display:none"});
		});

app.use(session ({
		secret: 'this-is -token',
		saveUninitialized: true, // (default: true)
		resave: true,
		cookie :{ maxAge : 1800000 },
		logedUser: ' ',
		})
	);
//console.log(session);
app.post('/post',function (req, res,next)
{
console.log("----------------");

  var username = req.body.username;
  var username_domain = 'att\\'+username;
  var password = req.body.password;
  var client = ldap.createClient({
    url: 'ldap://'+ldap_server
  });

  try{
		var opts = {
			 filter: '(sAMAccountName='+username+')',
		   scope: 'sub'
		};
		client.bind(username_domain,password,function(err,bind_res){
			if(err){
			  client.unbind(function(error) {
				if(error){
				  console.log(error.message);
				}
				else{
				  console.log('client disconnected');
				  console.log("Username/Password is incorrect!");
				  res.render('login',{divcss:"display:block"});
				}
			  });
			}
			else{

				  console.log('User: '+username+' authenticated through LDAP server at '+ new Date());
				  client.search('dc=att,dc=techmahindra,dc=com', opts, function(err, search_res)
				  {
						search_res.on('searchEntry', function(entry){
					  client.unbind(function(error) {
							if(error){
							  console.log("error.message");
							} else{
							  console.log('User: '+username+' disconnected from LDAP server at '+ new Date());
							}
						});
						req.session.authenticated = true;
						var string =entry.object.cn.split(" ");
						req.session.user = string[0];
						req.session.username = req.body.username;
						var url1 = '/report';
						res.redirect(url1);
			           // console.log(req.body.application);

					})

				});
			}
		});

}catch(error){
  console.log(error);
  client.unbind(function(error) {
    if(error){console.log(error.message);
    } else{
      console.log('User: '+username+' disconnected from LDAP server at '+ new Date());
    }});
}
next();
});


    app.post('/post',function (req, res) {
        var application = req.body.application;
        console.log(application);
    });




app.get('/logout', function (req, res, next) {
		delete req.session.authenticated;

		res.redirect('/');

	});
return app;
	};

//module.exports = loginRouter;
