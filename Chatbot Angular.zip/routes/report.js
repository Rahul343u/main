var ObjectID = require("mongodb").ObjectID;

module.exports = function(app,db){

 app.get('/report',function(req,res){
        db.automation.collection("projects").find({}).toArray(function(err,project){
            if(err){
                console.log(err.stack);
            }else{
                var projectName=[];
                var projectId=[];
                for(var i=0;i<project.length;i++){
                    projectName[i] = project[i].name;
                    projectId[i] = project[i]._id;
                
                
                }
               res.render('sidebar',{project : project,divcss: 'display:none;',user:req.session.user});
            }
        });
});
	
app.post('/report',function(req,res){
         console.log("Report POST request Called Successfully");
           
            var projectResult=[];
        db.automation.collection("projects").find({}).toArray(function(err,project){
            if(err){
                console.log(err.stack);
            }else{
                    db.automation.collection("projects").aggregate([{
                        $lookup:{
                            from:"executions",
                            localField:"name",
                            foreignField:"project",
                            as:"projectType"
					   }
                    }],function(err,projectData){
                        if(err){
                            console.log(err);                                   
                        }else{
                         
                            for(var i=0;i<project.length;i++){
                                var totalCount =0;
                                var passCount =0;
                                var failCount =0;
                                var notRunCount =0;
                              //  console.log(projectData[i]);
                               // if(projectData[i].projectType[0].project!==undefined || projectData[i].projectType[0].project!=="" ){
                                var projectName=projectData[i].name;
                                for(var j=0;j<projectData[i].projectType.length;j++){
                                    totalCount=totalCount+projectData[i].projectType[j].total;
                                    passCount=passCount+projectData[i].projectType[j].passed;
                                    failCount=failCount+projectData[i].projectType[j].failed;
                                    notRunCount=notRunCount+projectData[i].projectType[j].notRun;
                                    if(j==projectData[i].projectType.length-1){
                                        projectResult.push({projectName,totalCount,passCount,failCount,notRunCount});
                                    }
                                }
                            //}
                                if(i==project.length-1){
                                    
                                        res.send({projectResult:projectResult});
                                    }
                                
                        }
                        
                        }
                    });
                    
                
                    
            }
        });

});



	app.post('/:projectId/project',function(req,res){
    var projectId = req.body.projectId;
    var projectName = req.body.projectName;
        
        db.automation.collection("executions").find({project:projectName},{name:1,testsetname:1,lastRunDate:1,passed:1,failed:1,total:1,notRun:1,user:1}).toArray(function(err, projectList)
					{
                        if(err){
						console.log(err);
						}
						else {
                            res.send({projectList : projectList });
						}
					});
				});	
				
				
				
		app.post('/:id/report',function(req,res){
	var val = req.body.id;
    var para = req.body.para;
	//console.log("Parameter "+para);
	
					db.automation.collection("executions").find({_id:para}).toArray(function(err, executions)
					{
						if(err){
						console.log(err);
						}
						else {
                            var name;
							var passed;
							var id;
							var testsetname;
							var runtime;
							var failed;
							var total;
							var notRun;
							var user;
							var lastRunDate;
							var all=executions[0]; 
                             res.send({name : all.name,
										passed : all.passed,
										id : all._id,
										testsetname : all.testsetname,
										runtime : all.runtime,
										failed : all.failed,
										total : all.total,
										notRun : all.notRun,
										user : all.user,
										lastRunDate : all.lastRunDate,
                                        divcss : 'display:block;'}); 		
                        }
					});
});

app.post('/:id/table',function(req,res){
    var para = req.body.para;
        db.automation.collection("executiontestcases").find({executionID:para},{name:1,status:1,result:1}).toArray(function(err, executiontc){
            if(err){
						console.log(err);
						}
						else {
                             var testCaseName=executiontc;
                            res.send({  testCaseName : testCaseName});       
                        }
        });
   
});

    
app.post('/:screenId/viewScreens',function(req,res){
    var screenId = req.body.screenId;
   // console.log("testId "+testId);
   var downloadName;
        db.automation.collection("executiontestcases").find({_id:screenId},{resultID:1,_id:0,name:1}).toArray(function(err,screenData){
            if(err){
                console.log(err.stack);
            }else{
                                
             db.automation.collection("testcaseresults").find({_id: ObjectID(screenData[0].resultID)},{children:1,screenshot:1}).toArray(function(err,screenResult){
                    if(err){
                        console.log(err.stack);
                    }else{
                       downloadName =  screenData[0].name;
                       res.send({screenResult : screenResult,screenId:screenId,downloadName : downloadName }); 
                    }
                });
            }
        });
});

    
    
app.post('/download/:ss',function(req,res){
    var fileId = req.params.ss;
    console.log(fileId)
            db.automation.collection("screenshots").find({_id:fileId},{file:1,_id:0}).toArray(function(err,binaryResult){
                    if(err){
                        console.log(err.stack);
                    }else{
                       // console.log(binaryResult);
                        res.send({binaryResult : binaryResult});
                    }
                });
            
});
    
    
    
app.post('/:testId/testcase',function(req,res){
    var testId = req.body.test;
   // console.log("testId "+testId);
   
        db.automation.collection("executiontestcases").find({_id:testId},{resultID:1,_id:0}).toArray(function(err,testCase){
            if(err){
                console.log(err.stack);
            }else{
                var testData;
               //console.log(testCase);                
             db.automation.collection("testcaseresults").find({_id: ObjectID(testCase[0].resultID)},{children:1,screenshot:1}).toArray(function(err,testResult){
                    if(err){
                        console.log(err.stack);
                    }else{
                        res.send({testResult : testResult });
                    }
                });
            }
        });
});    
return app;
};