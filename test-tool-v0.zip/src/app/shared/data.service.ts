import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import 'rxjs/add/operator/map';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  result;
  token;
  url = '';
  constructor(private httpClient: HttpClient) { }

  setUrl(url:string) {
    this.url = url;
  }


  uploadtestCase(url: string, testcase: { title: string, description: string, reference: string }, tagValue ) {
    return this.httpClient
      .post('/uploadTestCasesToTaffy', {
        testcase: testcase,
        tagValue: tagValue,
        url: url
      })
      .map(result => {
        this.result = result;
        return result;
      });
  }

  getTestcaseTag(url:string) {
    return this.httpClient
      .post('/getTestcaseTag', {
        url: url
      })
      .map(result => {
        this.result = result;
        return result;
      });
  }

  getTestSetName(url: string) {
    return this.httpClient
      .post('/getTestSetName', {
        url: url
      })
      .map(result => {
        this.result = result;
        return result;
      });
  }

  getTestCasesByTag(url: string, tagValue:string) {
    return this.httpClient
      .post('/getTestCasesByTag', {
        url,
        tagValue
      })
      .map(result => {
        this.result = result;
        return result;
      });
  }

  getTestCasesByTagWithSteps(url: string, tagValue: string) {
    return this.httpClient
      .post('/getTestCasesByTagWithSteps', {
        url,
        tagValue
      })
      .map(result => {
        this.result = result;
        return result;
      });
  }

  getTestCasesBySetName(url: string, setValue: string) {
    return this.httpClient
      .post('/getTestCasesBySetName', {
        url,
        setValue
      })
      .map(result => {
        this.result = result;
        return result;
      });
  }

  getTestCasesBySetWithSteps(url: string, setValue: string) {
    return this.httpClient
      .post('/getTestCasesBySetWithSteps', {
        url,
        setValue
      })
      .map(result => {
        this.result = result;
        return result;
      });
  }

  updateTestCaseById(url: string, _id: string, name: string, description: string ) {
    let testcase = { _id, name, description };
    return this.httpClient
      .post('/updateTestCaseById', {
        url,
        testcase
      })
      .map(result => {
        this.result = result;
        return result;
      });
  }

  searchExistingTestcaseByName(url: string, name: string) {
    return this.httpClient
      .post('/SearchTestcaseByName', {
        url,
        name
      })
      .map(result => {
        this.result = result;
        return result;
      });
  }

  updateTestCaseDataById(testcase) {
    return this.httpClient
      .post('/updateTestCaseDataById', {
        url:this.url,
        testcase:testcase
      })
      .map(result => {
        this.result = result;
        return result;
      });
  }

}
