import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class StateDataService {
  private dataToUpload = [];
  private dataToUploadCreatedSheet = [];

  private testSheetCreated: { fileName: string, fileselectMethod: string, testcases: any[] } = { fileName: '', fileselectMethod: '', testcases: []};
  private createdSheetInfo: { pid: string, projectName: string, release: string, tagValue: string, currentStore: string, testCaseNumber: number } =
    { pid: '', projectName: '', release: '', tagValue: '', currentStore: '', testCaseNumber: 1 };

  private description = '';
  private reference = '';


  dataChanged = new Subject<any[]>();

  setdescReference(description: string, reference: string) {
    this.reference = reference;
    this.description = description;
  }

  getReference() { 
    return this.reference;
  }
  getDescription() {
    return this.description;
  }
  setData(dataToUpload:any[]) {
    this.dataToUpload = dataToUpload;
    this.dataChanged.next(this.dataToUpload.slice());
  }

  pushData(dataToUpload: { fileName: string, fileselectMethod: string, testcases: any[] }) {
    this.dataToUpload.push(dataToUpload);
    this.dataChanged.next(this.dataToUpload.slice());
  }

  getData() {
    return this.dataToUpload.slice();
  }

  getDataByIndex(index: number) {
    return this.dataToUpload[index];
  }

  deleteDataByIndex(index: number) {
    this.dataToUpload.splice(index, 1);
    this.dataChanged.next(this.dataToUpload.slice());
  }
  updateDataByIndex(index: number, testSheet: any[]) {
    this.dataToUpload[index] = testSheet;
    this.dataChanged.next(this.dataToUpload.slice());
  }

  deleteTestCaseByIndex(index: number, indexOfTestCase:number) {
    this.dataToUpload[index].testcases.splice(indexOfTestCase, 1);
    this.dataChanged.next(this.dataToUpload.slice());
  }
  fetchTestCaseByIndex(index: number, indexOfTestCase: number) {
    return this.dataToUpload[index].testcases[indexOfTestCase];
  }

  uploadTestCaseByIndex(index: number, indexOfTestCase: number,title:string,des:string,reference:string) {
   this.dataToUpload[index].testcases[indexOfTestCase].Title=title;
   this.dataToUpload[index].testcases[indexOfTestCase].Description=des;
   this.dataToUpload[index].testcases[indexOfTestCase].Reference = reference;
   this.dataChanged.next(this.dataToUpload.slice());
  }

  setTestSheetCreated(testSheetCreated: { fileName: string, fileselectMethod: string, testcases: any[] },
    sheetInfo: { pid: string, projectName: string, release: string, tagValue: string, currentStore: string, testCaseNumber:number }) {
    this.testSheetCreated = testSheetCreated;
    this.createdSheetInfo = sheetInfo;
  }
  getTestSheetCreated() {
    return (this.testSheetCreated);
  }
  getCreatedSheetInfo() {
    return (this.createdSheetInfo);
  }

}
