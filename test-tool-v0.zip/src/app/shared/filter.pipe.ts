import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(items: any[], searchText: string): any[] {
    if (!items) return [];
    if (!searchText) return items;

    searchText = searchText.toLowerCase();
    return items.filter(it => {
      if (it.description && it.name) {
      if (it.description.toLowerCase().includes(searchText) || it.name.toLowerCase().includes(searchText)) {
        return it;
      }
      }
      if (it.value) {
        return it.value.toLowerCase().includes(searchText);
      }
      if (it.name) {
        return it.name.toLowerCase().includes(searchText);
      }   
    });
  }
}
