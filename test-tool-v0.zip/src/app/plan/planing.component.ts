import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-planing',
  templateUrl: './planing.component.html',
  styleUrls: ['./planing.component.css']
})
export class PlaningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
