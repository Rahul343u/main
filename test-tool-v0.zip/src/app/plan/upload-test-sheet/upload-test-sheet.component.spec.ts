import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadTestSheetComponent } from './upload-test-sheet.component';

describe('UploadTestSheetComponent', () => {
  let component: UploadTestSheetComponent;
  let fixture: ComponentFixture<UploadTestSheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadTestSheetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadTestSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
