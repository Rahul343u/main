import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExportTestSheetComponent } from './export-test-sheet.component';

describe('ExportTestSheetComponent', () => {
  let component: ExportTestSheetComponent;
  let fixture: ComponentFixture<ExportTestSheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExportTestSheetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExportTestSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
