import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-export-test-sheet',
  templateUrl: './export-test-sheet.component.html',
  styleUrls: ['./export-test-sheet.component.css']
})
export class ExportTestSheetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
