import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { PlaningComponent } from './planing.component';
import { UploadTestSheetComponent } from './upload-test-sheet/upload-test-sheet.component';
import { CreateTestSheetComponent } from './create-test-sheet/create-test-sheet.component';
import { ExportTestSheetComponent } from './export-test-sheet/export-test-sheet.component';
import { TestcasesComponent } from './testcases/testcases.component';
import { TestcaseWithoutStepsComponent } from './testcases/testcase-without-steps/testcase-without-steps.component';
import { TestcaseWithStepsComponent } from './testcases/testcase-with-steps/testcase-with-steps.component';
import { FileDropDirective } from '../shared/file-drop.directive';
import { TestsheetComponent } from './testsheet/testsheet.component';
import { WorkbookComponent } from './testsheet/workbook/workbook.component';
import { TestCaseCreatedComponent } from './create-test-sheet/test-case-created/test-case-created.component';
import { WordLimitPipe } from '../shared/word-limit.pipe';
import { FilterPipe } from '../shared/filter.pipe';
import { OrderByPipePipe } from '../shared/order-by-pipe.pipe';
import { UpdateTestDataComponent } from './testcases/update-test-data/update-test-data.component';





@NgModule({
  declarations: [
    PlaningComponent,
    UploadTestSheetComponent,
    CreateTestSheetComponent,
    ExportTestSheetComponent,
    TestcasesComponent,
    TestcaseWithoutStepsComponent,
    TestcaseWithStepsComponent,
    FileDropDirective,
    TestsheetComponent,
    WorkbookComponent,
    TestCaseCreatedComponent,
    WordLimitPipe,
    FilterPipe,
    OrderByPipePipe,
    UpdateTestDataComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule
  ],
  exports: []
})
export class PlaningModule { }
