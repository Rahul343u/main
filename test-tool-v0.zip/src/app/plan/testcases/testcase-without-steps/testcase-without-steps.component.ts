import { Component, OnInit, OnDestroy, Input, ViewChild, ElementRef, AfterViewInit, AfterViewChecked, DoCheck } from '@angular/core';
import { TestcaseStateService } from '../../../shared/testcase-state.service';
import { Subscription } from 'rxjs/Subscription';
import * as XLSX from 'xlsx';
import { ExportToExcelService } from '../../../shared/export-to-excel.service';

@Component({
  selector: 'app-testcase-without-steps',
  templateUrl: './testcase-without-steps.component.html',
  styleUrls: ['./testcase-without-steps.component.css']
})
export class TestcaseWithoutStepsComponent implements OnInit, OnDestroy, AfterViewInit, DoCheck {
  @Input() searchTestcaseByKey = '';
  @ViewChild('table') table: ElementRef;
  subscription: Subscription;
  subscription1: Subscription;
  subscription2: Subscription;
  subscription3: Subscription;
  subscription4: Subscription;
  subscription5: Subscription;
  subscription6: Subscription;
  subscription7: Subscription;
  subscription8: Subscription;

  testcases = [];
  sn = false;
  sName = 'Test Suit Name';
  sDescription = 'Test Suit Description';
  user1 = 'user1';
  user2 = 'user2';
  user3 = 'user3';
  user4 = 'user4';
  user5 = 'user5';
  actionName = 'Launch Opus';
  actionDes = 'This Action should Launch OPUS';
  regprogvalue = 'Progression';
  testPhasevalue = 'Integrated Systems Test (IST)';
  priority = 'High';
  sortcol = 'name';
  applicationSelected = 'OPUS - C:18257';
  nonMOTSTeamSelected = 'RCC ST-OPUS';
  reverseSort = false;
  constructor(private testcaseStateService: TestcaseStateService,
    private etoexcelService: ExportToExcelService) { }


  sortData(name) {
    this.reverseSort = (this.sortcol === name) ? !this.reverseSort : false;
    this.sortcol = name;
  }




  ngOnInit() {
    this.testcases = this.testcaseStateService.getTestCases();
    this.sName = this.testcaseStateService.getSuitName();
    this.sDescription = this.testcaseStateService.getSuitDescription();
    this.user1 = this.testcaseStateService.getUser1Modified();
    this.user2 = this.testcaseStateService.getUser2Modified();
    this.regprogvalue = this.testcaseStateService.getRegreProgression();
    this.applicationSelected = this.testcaseStateService.getApplicationSelected();
    this.nonMOTSTeamSelected = this.testcaseStateService.getNonMOTSTeamSelected();
    this.testPhasevalue = this.testcaseStateService.getTestPhaseSelected();
    
    
    this.subscription = this.testcaseStateService.testCasesChanged.subscribe(
      (testcases: any[]) => {
        this.testcases = testcases;
      }
    );

    this.subscription1 = this.testcaseStateService.testSuitNameChanged.subscribe(
      (suitName: string) => {
        this.sName = suitName;
      });

    this.subscription2 = this.testcaseStateService.testSuitDescriptionChanged.subscribe(
      (sDescription: string) => {
        this.sDescription = sDescription;
      });

    this.subscription3 = this.testcaseStateService.testPhaseSelectedChanged.subscribe(
      (testPhasevalue: string) => {
        this.testPhasevalue = testPhasevalue;
      });


    this.subscription4 = this.testcaseStateService.regreProgressionChanged.subscribe(
      (regprogvalue: string) => {
        this.regprogvalue = regprogvalue;
      });
    this.subscription5 = this.testcaseStateService.applicationSelectedChanged.subscribe(
      (applicationSelected: string) => {
        this.applicationSelected = applicationSelected;
      });

    this.subscription6 = this.testcaseStateService.nonMOTSTeamSelectedChanged.subscribe(
      (nonMOTSTeamSelected: string) => {
        this.nonMOTSTeamSelected = nonMOTSTeamSelected;
      });
    this.subscription7 = this.testcaseStateService.user1ModifiedChanged.subscribe(
      (user1: string) => {
        this.user1 = user1;
      });
    this.subscription8 = this.testcaseStateService.user2ModifiedChanged.subscribe(
      (user2: string) => {
        this.user2 = user2;
      });

  }
  ngAfterViewInit() {
    this.etoexcelService.setTableWithoutStepsToExport(this.table);
  }
  ngDoCheck() {
    this.etoexcelService.setTableWithoutStepsToExport(this.table);
  }
  ngOnDestroy() {
    this.subscription.unsubscribe;
    this.subscription1.unsubscribe;
    this.subscription2.unsubscribe;
    this.subscription3.unsubscribe;
    this.subscription4.unsubscribe;
    this.subscription5.unsubscribe;
    this.subscription6.unsubscribe;
    this.subscription7.unsubscribe;
    this.subscription8.unsubscribe;
  }
}
