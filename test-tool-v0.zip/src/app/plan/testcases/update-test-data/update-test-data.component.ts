import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { ExportToExcelService } from '../../../shared/export-to-excel.service';
import { TestcaseStateService } from '../../../shared/testcase-state.service';
import { Subscription } from 'rxjs';
import { DataService } from '../../../shared/data.service';

@Component({
  selector: 'app-update-test-data',
  templateUrl: './update-test-data.component.html',
  styleUrls: ['./update-test-data.component.css']
})
export class UpdateTestDataComponent implements OnInit, OnDestroy {

  @Input() searchTestcaseByKey = '';

  subscription: Subscription;

  testcases;
  sortcol = 'name';
  reverseSort = false;
  keys = [];
  updatedTestcase;
  updatedDataLine = 0;
  updateAll = false;

  constructor(private testcaseStateService: TestcaseStateService,
    private etoexcelService: ExportToExcelService,
    private dataService: DataService) { }


  sortData(name) {
    this.reverseSort = (this.sortcol === name) ? !this.reverseSort : false;
    this.sortcol = name;
  }

  public getKeys(data) {
    this.keys = Object.keys(data);
    return true;
  }

  tcDataChangedSubmitted(testcase) {
    this.updatedTestcase = null;
    this.updateAll = true;
    this.dataService.updateTestCaseDataById(testcase).subscribe((result) => {
      this.updatedTestcase = result;
    });
  }

  tcDataChangedSubmittedUsingDataLine(testcase, updatedDataLine) {
    this.updatedTestcase = null;
    this.updatedDataLine = updatedDataLine;
    this.updateAll = false;
    this.dataService.updateTestCaseDataById(testcase).subscribe((result) => {
      this.updatedTestcase = result;
    });
  }

  ngOnInit() {
    this.testcases = this.testcaseStateService.getTestCases();

    this.subscription = this.testcaseStateService.testCasesChanged.subscribe(
      (testcases: any[]) => {
        this.testcases = testcases;
      }
    );
  }


  ngOnDestroy() {
    this.subscription.unsubscribe;
  }

}
