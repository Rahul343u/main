var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');
var http = require('http');
var app = express();

var mongoConne = require('./server/DB/mongoConnect');

var api = require('./server/api');
var port = 3000;

app.use(express.static(__dirname + '/public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(express.static(path.join(__dirname, 'dist/test-tool-v0')));

app.get('*',
  (req, res) => {
    res.sendFile(path.join(__dirname, 'dist/test-tool-v0/index.html'));
  });


mongoConne(function (err, dbs) {
  if (err)
    console.log(err);
  api(app, dbs);
});



app.listen(port, function () {
  console.log('Server is running on port ' + port);
});



