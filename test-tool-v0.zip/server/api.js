var ObjectID = require('mongodb').ObjectID;

module.exports = function (app, dbs) {
  app.post('/uploadTestCasesToTaffy', (req, res) => {
    
    let url = req.body.url;
   
    if (req.body.tagValue && req.body.testcase.title && req.body.testcase.reference) {
      
    dbs[url].collection("testcaseTags").findOne({ value: req.body.tagValue }, function (err, tag) {
      if (err) throw err;
      if (tag != null) {
       // console.log('Tag Already exists');
      } else {

        if (url === 'OPUS_automation') {
          var myobj = { value: req.body.tagValue, project: "OPUS Master" };
        }
        else if (url === 'OM_automation') {
          var myobj = { value: req.body.tagValue, project: "OPUSMobile Master" };
        }
        else if (url === 'Other_automation') {
          var myobj = { value: req.body.tagValue, project: "OPUS Master" };
        }

        dbs[url].collection("testcaseTags").insertOne(myobj, function (err, res) {
          if (err) throw err;
          console.log("Tag inserted");
        });
      }
      });
     

      dbs[url].collection("testcases").findOne({ name: req.body.testcase.title.trim() }, function (err, testExists) {
        if (err) throw err;
      if (testExists === null) {
        dbs[url].collection("testcases").findOne({ name: req.body.testcase.reference.trim() }, function (err, result) {
          if (err) throw err;
          if (result != null) {
            result._id = new ObjectID();
            result.name = req.body.testcase.title;
            result.description = req.body.testcase.description;
            result.tag[0] = req.body.tagValue;
            dbs[url].collection("testcases").insertOne(result, function (err, resultInsert) {
              if (err) throw err;          
              res.send({ testcase: req.body.testcase, success: true, errorMessage: 'Upload Successful' });
            });
          } else {
            res.send({ testcase: req.body.testcase, success: false, errorMessage: 'Reference not found' });
          }       
        });
      } else { 
        res.send({ testcase: req.body.testcase, success: false, errorMessage: 'Test case already exists' });
      }
      });  
    } 
  });


  app.post('/getTestcaseTag', (req, res) => {
 
    let url = req.body.url;
   

    dbs[url].collection("actions").find({ temp: null }).toArray(function (err, result) {
          if (err) {
            return console.log('error', err);
          }
          for (var i = 0; i < result.length; i++) {
            dbs[url].collection("actions").updateOne({
              _id: result[i]._id
            },
              {
                $set: {
                  temp: result[i]._id.toString()
                }
              }
            );
          }

        });

    dbs[url].collection("testcases").find({ temp: null }).toArray(function (err, result) {
          if (err) {
            return console.log('error', err);
          }
          for (var i = 0; i < result.length; i++) {
            dbs[url].collection("testcases").updateOne({
              _id: result[i]._id
            },
              {
                $set: {
                  temp: result[i]._id.toString()
                }
              }
            );
          }

        });


    dbs[url].collection("testcaseTags").find({}).toArray(function (err, tags) {
   
          if (err) {
            return console.log('error', err);
          }
          res.send(tags);
        });
  });


  app.post('/getTestSetName', (req, res) => {

    let url = req.body.url;

    dbs[url].collection("actions").find({ temp: null }).toArray(function (err, result) {
          if (err) {
            return console.log('error', err);
          }
          for (var i = 0; i < result.length; i++) {
            dbs[url].collection("actions").updateOne({
              _id: result[i]._id
            },
              {
                $set: {
                  temp: result[i]._id.toString()
                }
              }
            );
          }

        });

    dbs[url].collection("testcases").find({ temp: null }).toArray(function (err, result) {
          if (err) {
            return console.log('error', err);
          }
          for (var i = 0; i < result.length; i++) {
            dbs[url].collection("testcases").updateOne({
              _id: result[i]._id
            },
              {
                $set: {
                  temp: result[i]._id.toString()
                }
              }
            );
          }

        });


    dbs[url].collection("testsets").find({}, {  testcases: 0  }).toArray(function (err, testSets) {
          if (err) {
            return console.log('error', err);
          }
          res.send(testSets);
        });
  });


  app.post('/getTestCasesByTag', (req, res) => {
    
    let url = req.body.url;
    if (req.body.tagValue) {
    dbs[url].collection("testcases").find({ "tag": req.body.tagValue },  { _id: 1, "name": 1, "description": 1, "user": 1, "tcData":1 } ).toArray(function (err, testcases) {
          if (err) {
            return console.log('error', err);
          }
          res.send(testcases);
        });
    }
  });


  app.post('/getTestCasesBySetName', (req, res) => {

    let url = req.body.url;
    if (req.body.setValue) {
      dbs[url].collection("testsets").findOne({ name: req.body.setValue }, (err, testSet) => {
        if (err) {
          return console.log('unable to fetch test set info', err);
        }
        let testcaseid = [];
        testSet.testcases.forEach((testcase) => {
          testcaseid.push(new ObjectID(testcase._id));
        });

        dbs[url].collection("testcases").find({ _id: { $in: testcaseid } }, { _id: 1, "name": 1, "description": 1, "user": 1, "tcData": 1 } ).toArray(function (err, testcases) {
          if (err) {
            return console.log('error', err);
          }
          res.send(testcases);

        });
      });
    }
  });


  app.post('/getTestCasesByTagWithSteps', (req, response) => {
    
    let url = req.body.url;
    if (req.body.tagValue) {
      dbs[url].collection("testcases").aggregate([
        { $match: { "tag": req.body.tagValue } },
        { "$unwind": "$collection" },
        {
          $lookup: {
            from: "actions",
            localField: "collection.actionid",
            foreignField: "temp",
            as: "details"
          }
        }, {
          $project:
          {
            "_id": 1,
            "name": 1,
            "description": 1,
            "user": 1,
            "tcData": 1,
            "details": { "name": 1, "description": 1 }
          }
        },
        { "$unwind": "$details" },
        {
          $group: {
            "_id": "$_id",
            "name": { "$first": "$name" },
            "user": { "$first": "$user" },
            "tcData": { "$first": "$tcData" },
            "description": { "$first": "$description" },
            "actiondetails": { "$push": "$details" },

          },
        }
      ]).toArray(function (err, testcases) {
        if (err) {
          return console.log('error', err);
        }
        response.send(testcases);
      });
    }
  });


  app.post('/getTestCasesBySetWithSteps', (req, response) => {

    let url = req.body.url;
    if (req.body.setValue) {
      dbs[url].collection("testsets").aggregate([
        { $match: { "name": req.body.setValue } },
        { "$unwind": "$testcases" },
        {
          $lookup: {
            from: "testcases",
            localField: "testcases._id",
            foreignField: "temp",
            as: "testcasesDetails"
          }
        }, {
          $project:
          {
            "_id": 1,
            "name": 1,
            "testcasesDetails": { "_id": 1, "name": 1, "description": 1, "user": 1, "collection": 1, "tcData": 1 }
          }
        },
        { "$unwind": "$testcasesDetails" },
        { "$unwind": "$testcasesDetails.collection" },
        {
          $lookup: {
            from: "actions",
            localField: "testcasesDetails.collection.actionid",
            foreignField: "temp",
            as: "details"
          }
        }, {
          $project:
          {
            "testcasesDetails._id": 1,
            "testcasesDetails.name": 1,
            "testcasesDetails.description": 1,
            "testcasesDetails.user": 1,
            "testcasesDetails.tcData": 1,
            "details": { "name": 1, "description": 1 }
          }
        },
        { "$unwind": "$details" },
        {
          $group: {
            "_id": "$testcasesDetails._id",
            "name": { "$first": "$testcasesDetails.name" },
            "user": { "$first": "$testcasesDetails.user" },
            "description": { "$first": "$testcasesDetails.description" },
            "tcData": { "$first": "$testcasesDetails.tcData" },
            "actiondetails": { "$push": "$details" },

          },
        }

      ]).toArray(function (err, testcases) {
        if (err) {
          return console.log('error', err);
        }
        response.send(testcases);
      });
    }
  });

  app.post('/updateTestCaseById', (req, res) => {
    
    let url = req.body.url;
    if (req.body.testcase._id) {
    
        dbs[url].collection("testcases").findOneAndUpdate({ _id: new ObjectID(req.body.testcase._id) },
          {
            $set: {
              name: req.body.testcase.name,
              description: req.body.testcase.description
            }
          },
          { new: true }, function (err, doc) {
            if (err) { throw err; }
            else {
              res.send(doc);
            }
        });
    }
  });


  app.post('/updateTestCaseDataById', (req, res) => {

    let url = req.body.url;
    if (req.body.testcase._id) {

      dbs[url].collection("testcases").findOneAndUpdate({ _id: new ObjectID(req.body.testcase._id) },
        {
          $set: {
            tcData: req.body.testcase.tcData
          }
        },
        { new: true }, function (err, doc) {
          if (err) { throw err; }
          else {
            res.send(doc);
          }
        });
    }
  });

  app.post('/SearchTestcaseByName', (req, res) => {
    
    let url = req.body.url;
    if (req.body.name) {
      dbs[url].collection("testcases").findOne({ name: req.body.name.trim() }, function (err, testExists) {
        if (err) throw err;
        if (testExists === null) {
          res.send({ name: req.body.name, success: true, errorMessage: 'Unique Name' });

        } else {
          res.send({ name: req.body.name, success: false, errorMessage: 'Test case already exists' });

        }
      });
    }
  });
  return app;
};
